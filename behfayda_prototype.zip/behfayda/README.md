# BehFayda Bench — continuous-authentication benchmark prototype (research)

PhD research prototype for *Multi-Modal Biometric Fusion for Adaptive Continuous Authentication in National
Digital Identity Systems* (A. K. Aseres, AASTU). Build 2.0.0-research.
**Not connected to Fayda / NIDP / FaydaVerse. Demo identities only.** Full instructions: `INSTALL.md`.

## What it does
1. **Collect** behavioural biometrics: taps, typing (English and a two-tier Amharic Fidel keyboard), swipes.
2. **Train** a personal profile with BehEnc-MLP, the best deployable deep encoder of the dissertation's benchmark
   (Chapter 6): window embeddings, cosine template, leave-one-out calibration, same-domain cohort when available.
3. **Protect** a demo bank session: evidence gate, K = 5 assurance A, calibrated CUSUM takeover statistic,
   session risk R = 1 − A(1 − min(1, S/h)), step-up, verified-label updates, SABA bounded adaptation, rollback.
4. **Enforce**: voice + tone alarm and forced logout on suspected takeover; step-up, then logout, at high risk.
5. **Benchmark**: multi-participant collection, the dissertation's protocol on the collected data, live takeover
   trials, JSON export; replay on real BahriApp data.

## Measured
- Shipped encoder, offline on BahriApp (3 user-disjoint folds, temporal split, unseen impostors, cosine head), median
  per-user EER K = 1 / 5 / 10: tap 19.9 / 11.2 / 8.9 %, keystroke 26.8 / 12.5 / 5.2 %, swipe 28.2 / 19.9 / 16.1 %.
- 19 pytest tests pass, including JavaScript–Python parity of the deep pipeline; Playwright end-to-end test passes.
- Scoring latency ≈ 0.5 ms per window in JavaScript.

## Layout
See INSTALL.md §1.1. Experiments: `research/`. Encoder: `models/behenc_mlp_v1.json`.
