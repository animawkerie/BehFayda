"""Inline the engine, the encoder, the exported model, the background cohort and the replay bundle into
frontend/index.html so the prototype runs from a single file (no server needed)."""
import json, os, sys
h = os.path.dirname(os.path.abspath(__file__))
model_path = os.environ.get('BEHFAYDA_MODEL', f'{h}/models/behenc_mlp_v1.json')
html = open(f'{h}/frontend/app.html').read()
core = open(f'{h}/frontend/core.js').read(); enc = open(f'{h}/frontend/encoder.js').read()
bg = json.load(open(f'{h}/backend/data/background.json'))['modalities']
rb = json.load(open(f'{h}/backend/data/replay_bundle.json'))
model = json.load(open(model_path)) if os.path.exists(model_path) else None
off_path = f'{h}/models/offline_table.html'
offline = open(off_path).read() if os.path.exists(off_path) else None
html = (html.replace('/*__CORE__*/', core).replace('/*__ENC__*/', enc)
        .replace('/*__BG__*/null', json.dumps(bg, separators=(',', ':')))
        .replace('/*__RB__*/null', json.dumps(rb, separators=(',', ':')))
        .replace('/*__MODEL__*/null', json.dumps(model, separators=(',', ':')) if model else 'null')
        .replace('/*__OFFLINE__*/null', json.dumps(offline) if offline else 'null'))
open(f'{h}/frontend/index.html', 'w').write(html)
print('index.html bytes', len(html), 'model', 'bundled' if model else 'MISSING')
