"""Benchmark protocol for data collected with the prototype (multi-participant, same capture domain).

For every participant P with enough windows:
  enrolment = P's 'enrol'-phase windows (or, if none are labelled, P's earliest 60% of windows by time);
  genuine test = P's remaining windows (later in time than every enrolment window);
  impostor test = the test windows of every OTHER participant (never used to build P's template).
Verifiers compared on identical windows:
  deep  : BehEnc-MLP embedding + cosine template (enrol_deep), cohort-free calibration
  stats : window-statistics one-class template (enrol), the prototype's v1 verifier
Reported: per-participant EER at K = 1, 3, 5 (K consecutive windows averaged), median over participants,
accuracy at the EER point (1 - EER), and FAR / FRR at the template's own operating threshold tau.
"""
from __future__ import annotations
import numpy as np
from .core import enrol, enrol_deep, window_vector, Params


def eer(gen: np.ndarray, imp: np.ndarray) -> float:
    """accept if score <= t (scores are distances, lower = more genuine)."""
    thr = np.unique(np.r_[gen, imp]); best = (2.0, 0.5)
    for t in thr:
        frr = float((gen > t).mean()); far = float((imp <= t).mean())
        if abs(frr - far) < best[0]: best = (abs(frr - far), (frr + far) / 2)
    return best[1]


def kagg(v: np.ndarray, K: int) -> np.ndarray:
    return v if K <= 1 else np.array([v[i:i + K].mean() for i in range(0, len(v) - K + 1, K)])


def run(samples: list[dict], modality: str, encoder=None, Ks=(1, 3, 5), min_enrol=4, min_test=3) -> dict:
    """samples: [{participant, modality, phase, ts, events}] ordered arbitrarily."""
    S = sorted([s for s in samples if s['modality'] == modality], key=lambda s: s['ts'])
    parts = sorted({s['participant'] for s in S})
    split = {}
    for p in parts:
        mine = [s for s in S if s['participant'] == p]
        en = [s for s in mine if s['phase'] == 'enrol']; te = [s for s in mine if s['phase'] == 'test']
        if not te:  # chronological fallback
            c = max(min_enrol, int(round(0.6 * len(mine)))); en, te = mine[:c], mine[c:]
        split[p] = (en, te)
    p0 = Params(); verifiers = {'stats': None}
    if encoder is not None and modality in encoder.m['modalities']:
        verifiers['deep'] = encoder
    out = {'modality': modality, 'participants': [], 'summary': {}}
    for name, enc in verifiers.items():
        feat = (lambda ev: enc.embedding(ev, modality)) if enc is not None else (lambda ev: window_vector(ev, modality))
        per = {K: [] for K in Ks}; ops = []
        for p in parts:
            en, te = split[p]
            imp = [s for q in parts if q != p for s in split[q][1]]
            if len(en) < min_enrol or len(te) < min_test or len(imp) < min_test:
                continue
            V = [feat(s['events']) for s in en]
            t = enrol_deep(modality, V, p0) if enc is not None else enrol(modality, V, p0)
            sc = lambda s: t.score(feat(s['events']), p0)[0]
            g = np.array([sc(s) for s in te]); b = {q: np.array([sc(s) for s in split[q][1]]) for q in parts if q != p and split[q][1]}
            for K in Ks:
                gk = kagg(g, K); parts_k = [kagg(v, K) for v in b.values() if len(v) >= K]
                bk = np.concatenate(parts_k) if parts_k else np.array([])
                if len(gk) >= 1 and len(bk) >= 1:
                    per[K].append(eer(gk, bk))
            ball = np.concatenate(list(b.values()))
            ops.append({'participant': p, 'verifier': name, 'n_enrol': len(en), 'n_genuine': len(g), 'n_impostor': len(ball),
                        'frr_at_tau': round(float((g > t.tau).mean()), 3), 'far_at_tau': round(float((ball <= t.tau).mean()), 3),
                        'eer_K1': round(eer(g, ball), 3)})
        out['participants'] += ops
        out['summary'][name] = {f'K{K}': {'n': len(v), 'median_eer': None if not v else round(float(np.median(v)), 4),
                                          'accuracy_at_eer': None if not v else round(1 - float(np.median(v)), 4)} for K, v in per.items()}
    return out
