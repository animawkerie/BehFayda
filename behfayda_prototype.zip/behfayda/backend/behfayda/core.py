"""BehFayda assurance engine (reference implementation).

Implements, in one place, the algorithms the dissertation evaluates offline:
  * window featurisation of behavioural events (Ch. 5 protocol: event-scope features only)
  * robust one-class template and cohort-free score normalisation
  * evidence gate + K-window evidence accumulation with abstention (BIAL, P8)
  * one-sided CUSUM takeover detector with a bound calibrated on genuine enrolment streams (P8)
  * separation of the access decision from the update decision (P5, P7)
  * verified-label updating by default, silent admission only under SABA's anchored,
    trust-region-bounded, rate-capped, angle-screened update (P6)
  * versioned profiles with rollback on failed step-up (P5 recovery)

The JavaScript engine in frontend/core.js is a line-for-line port; tests/test_parity.py checks it.
"""
from __future__ import annotations
import math, time, copy
from dataclasses import dataclass, field, asdict
import numpy as np

# ----------------------------------------------------------------- featurisation
EVENT_FEATURES = {
    "tap": ["duration_ms", "move_x", "move_y", "off_x", "off_y"],
    "swipe": ["duration_ms", "distance", "speed", "straightness"],
    "key": ["hold_ms", "flight_ms"],
}
WINDOW_EVENTS = {"tap": 12, "swipe": 5, "key": 9}
MIN_EVENTS = {"tap": 8, "swipe": 4, "key": 6}  # evidence gate q (per window)


def window_vector(events: list[dict], modality: str) -> np.ndarray:
    """mean, std, median of each event feature over one window (NaN-robust)."""
    cols = EVENT_FEATURES[modality]
    X = np.array([[float(e.get(c, np.nan)) if e.get(c) is not None else np.nan for c in cols]
                  for e in events], dtype=float)
    with np.errstate(all="ignore"):
        mean = np.nanmean(X, 0); std = np.nanstd(X, 0); med = np.nanmedian(X, 0)
    v = np.concatenate([mean, std, med])
    return np.nan_to_num(v, nan=0.0)


# ----------------------------------------------------------------- parameters
@dataclass
class Params:
    tau_quantile: float = 0.90      # accept if s <= q90 of genuine enrolment scores (SABA calibration rule)
    gate_quantile: float = 0.50     # silent-admission gate = median genuine score (SABA tau_g)
    kappa: float = 0.974            # angular screen (SABA, Table VI)
    eta: float = 0.2                # update rate (SABA)
    region_radius: float = 1.5      # lifetime trust region radius, z-units (demo calibration)
    daily_cap: float = 0.5          # max profile displacement per day, z-units
    K: int = 5                      # evidence budget (windows averaged per decision)
    trust_level: float = 0.70       # assurance >= this -> TRUSTED
    stepup_level: float = 0.45      # assurance < this -> STEP_UP
    high_risk_level: float = 0.80   # high-risk action requires assurance >= this
    cusum_margin: float = 1.2       # bound = margin * max CUSUM on genuine enrolment stream
    imp_shift_sd: float = 2.0       # assumed impostor mean shift (genuine SDs) for the LLR
    clip_z: float = 6.0


# ----------------------------------------------------------------- template
@dataclass
class ModalityTemplate:
    modality: str
    center: list
    scale: list
    anchor: list          # mu_0 in z-space (zeros by construction; kept explicit)
    mu: list              # adaptive profile in z-space
    g_med: float          # median genuine distance (LOO)
    g_mad: float          # spread of genuine distance
    tau: float            # acceptance threshold on normalised score s
    tau_g: float          # silent admission gate on s
    cusum_bound: float
    day_start_mu: list
    day_index: int = 0
    last_step: list | None = None
    n_enrol: int = 0

    weights: list | None = None   # logistic verifier (background-cohort mode); None = one-class mode
    imp_shift: float | None = None
    kind: str = "stat"            # "stat" = window statistics; "deep" = BehEnc embedding, cosine template
    radius: float | None = None   # SABA lifetime trust-region radius in this template's space (None = Params)
    cap: float | None = None      # SABA daily cap in this template's space (None = Params)

    # --- scoring
    def z(self, v: np.ndarray, p: Params) -> np.ndarray:
        if self.kind == "deep":
            return np.asarray(v, float)
        z = (np.asarray(v) - np.asarray(self.center)) / np.asarray(self.scale)
        return np.clip(z, -p.clip_z, p.clip_z)

    def distance(self, z: np.ndarray) -> float:
        d = z - np.asarray(self.mu)
        return float(np.sqrt(np.mean(d * d)))

    def raw(self, z: np.ndarray) -> float:
        """Raw negative-evidence statistic. Logistic mode: -logit of the verifier applied to the input
        translated by the bounded profile displacement (mu - mu0): an anchored, bounded shift of the
        decision region, so SABA's Proposition 1 applies to the effective template."""
        if self.kind == "deep":
            mu = np.asarray(self.mu)
            return 1.0 - float(z @ mu / (np.linalg.norm(z) * np.linalg.norm(mu) + 1e-12))
        if self.weights is None:
            return self.distance(z)
        x = z - (np.asarray(self.mu) - np.asarray(self.anchor))
        w = np.asarray(self.weights)
        return -float(x @ w[:-1] + w[-1])

    def score(self, v: np.ndarray, p: Params) -> tuple[float, np.ndarray]:
        z = self.z(v, p)
        s = (self.raw(z) - self.g_med) / self.g_mad
        return float(s), z


def _robust_scale(E: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    c = np.median(E, 0)
    q75, q25 = np.percentile(E, 75, 0), np.percentile(E, 25, 0)
    sc = (q75 - q25) / 1.349
    sd = E.std(0)
    sc = np.where(sc > 1e-6, sc, np.where(sd > 1e-6, sd, 1.0))
    return c, sc


def train_logreg(X: np.ndarray, y: np.ndarray, l2: float = 1e-2, iters: int = 400, lr: float = 0.5) -> np.ndarray:
    """Class-balanced L2 logistic regression by full-batch gradient descent (mirrored in core.js)."""
    n, d = X.shape
    Xb = np.hstack([X, np.ones((n, 1))])
    wpos = 0.5 / max(y.sum(), 1); wneg = 0.5 / max((1 - y).sum(), 1)
    sw = np.where(y == 1, wpos, wneg)
    w = np.zeros(d + 1)
    for _ in range(iters):
        p_ = 1 / (1 + np.exp(-np.clip(Xb @ w, -30, 30)))
        g = Xb.T @ (sw * (p_ - y)) + l2 * np.r_[w[:-1], 0.0]
        w -= lr * g
    return w


def enrol(modality: str, windows: list[np.ndarray], p: Params = Params(),
          background: list[np.ndarray] | None = None) -> ModalityTemplate:
    E = np.vstack(windows)
    if len(E) < 4:
        raise ValueError("need at least 4 enrolment windows")
    if background is not None and len(background) >= 20:
        return _enrol_logistic(modality, E, np.vstack(background), p)
    c, sc = _robust_scale(E)
    Z = np.clip((E - c) / sc, -p.clip_z, p.clip_z)
    # leave-one-out genuine distances to the anchor (mean of the other windows)
    n = len(Z); tot = Z.sum(0)
    loo = np.array([np.sqrt(np.mean(((Z[i] - (tot - Z[i]) / (n - 1))) ** 2)) for i in range(n)])
    g_med = float(np.median(loo))
    g_mad = float(max(np.median(np.abs(loo - g_med)) * 1.4826, 1e-3))
    s = (loo - g_med) / g_mad
    tau = float(np.quantile(s, p.tau_quantile))
    tau_g = float(np.quantile(s, p.gate_quantile))
    # CUSUM bound calibrated on the genuine (LOO) score stream, P8
    S = 0.0; smax = 0.0
    for si in s:
        S = max(0.0, S + llr(si, p)); smax = max(smax, S)
    bound = float(max(p.cusum_margin * smax, 3.0))
    anchor = Z.mean(0)
    return ModalityTemplate(modality, c.tolist(), sc.tolist(), anchor.tolist(), anchor.tolist(),
                            g_med, g_mad, tau, tau_g, bound, anchor.tolist(), 0, None, n)


def enrol_deep(modality: str, emb: list[np.ndarray], p: Params = Params(),
               cohort: list[np.ndarray] | None = None) -> ModalityTemplate:
    """Cosine template on BehEnc embeddings (the deep benchmark's 'cos' head, Ch. 6).
    Calibration: leave-one-out cosine distances of the enrolment windows; if embeddings of OTHER participants
    captured on the same deployment are available (benchmark mode), the threshold is the EER point between
    LOO-genuine and cohort scores and the CUSUM impostor shift is estimated from the cohort."""
    E = np.vstack(emb)
    if len(E) < 4:
        raise ValueError("need at least 4 enrolment windows")
    n = len(E); tot = E.sum(0)
    cosd = lambda a, b: 1.0 - float(a @ b / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-12))
    loo = np.array([cosd(E[i], (tot - E[i]) / (n - 1)) for i in range(n)])
    g_med = float(np.median(loo)); g_mad = float(max(np.median(np.abs(loo - g_med)) * 1.4826, 1e-3))
    sg = (loo - g_med) / g_mad
    anchor = E.mean(0)
    shift = None
    if cohort is not None and len(cohort) >= 8:
        sb = np.array([(cosd(c, anchor) - g_med) / g_mad for c in np.vstack(cohort)])
        tau = eer_threshold(sg, sb); shift = float(max(np.median(sb), 1.0))
    else:
        tau = float(np.quantile(sg, p.tau_quantile))
    tau_g = float(np.quantile(sg, p.gate_quantile))
    S = 0.0; smax = 0.0
    for si in sg:
        S = max(0.0, S + llr(si, p, shift)); smax = max(smax, S)
    bound = float(max(p.cusum_margin * smax, 3.0))
    spread = float(np.median(np.linalg.norm(E - anchor, axis=1)))
    return ModalityTemplate(modality, [0.0] * E.shape[1], [1.0] * E.shape[1], anchor.tolist(), anchor.tolist(), g_med, g_mad,
                            tau, tau_g, bound, anchor.tolist(), 0, None, n, None, shift, "deep",
                            radius=1.5 * spread, cap=0.5 * spread)


def _enrol_logistic(modality: str, E: np.ndarray, B: np.ndarray, p: Params) -> ModalityTemplate:
    c = E.mean(0); sc = np.vstack([E, B]).std(0); sc = np.where(sc > 1e-6, sc, 1.0)
    ZE = np.clip((E - c) / sc, -p.clip_z, p.clip_z); ZB = np.clip((B - c) / sc, -p.clip_z, p.clip_z)
    X = np.vstack([ZE, ZB]); y = np.r_[np.ones(len(ZE)), np.zeros(len(ZB))]
    # 3-fold out-of-fold raw statistics for calibration (deterministic interleaved folds)
    fold = np.arange(len(X)) % 3
    raw = np.zeros(len(X))
    for f in range(3):
        w = train_logreg(X[fold != f], y[fold != f])
        Xb = np.hstack([X[fold == f], np.ones(((fold == f).sum(), 1))])
        raw[fold == f] = -(Xb @ w)
    w = train_logreg(X, y)
    rg, rb = raw[y == 1], raw[y == 0]
    g_med = float(np.median(rg)); g_mad = float(max(np.median(np.abs(rg - g_med)) * 1.4826, 1e-3))
    sg, sb = (rg - g_med) / g_mad, (rb - g_med) / g_mad
    tau = eer_threshold(sg, sb)
    tau_g = float(np.median(sg))
    shift = float(max(np.median(sb), 1.0))
    S = 0.0; smax = 0.0
    for si in sg:
        S = max(0.0, S + llr(si, p, shift)); smax = max(smax, S)
    bound = float(max(p.cusum_margin * smax, 3.0))
    anchor = ZE.mean(0)
    return ModalityTemplate(modality, c.tolist(), sc.tolist(), anchor.tolist(), anchor.tolist(), g_med, g_mad,
                            tau, tau_g, bound, anchor.tolist(), 0, None, len(E), w.tolist(), shift)


def eer_threshold(sg: np.ndarray, sb: np.ndarray) -> float:
    """Threshold on s (accept if s <= t) where genuine rejection ~= impostor acceptance."""
    cand = np.unique(np.r_[sg, sb]); best, bt = 9.0, float(np.median(sg))
    for t in cand:
        frr = (sg > t).mean(); far = (sb <= t).mean()
        if abs(frr - far) < best: best, bt = abs(frr - far), float(t)
    return bt


def llr(s: float, p: Params, shift: float | None = None) -> float:
    """log p_imp(s)/p_gen(s); genuine s ~ N(0,1) by construction, impostor ~ N(shift,1).
    shift is estimated from the background cohort at enrolment (logistic mode)."""
    d = p.imp_shift_sd if shift is None else shift
    return d * s - 0.5 * d * d


def confidence(s: float, tau: float) -> float:
    """Monotone identity-confidence in [0,1]; 0.5 at the acceptance threshold."""
    return 1.0 / (1.0 + math.exp(2.0 * (s - tau)))


# ----------------------------------------------------------------- SABA bounded update
def saba_update(t: ModalityTemplate, z: np.ndarray, p: Params, day_index: int) -> tuple[bool, str]:
    mu = np.asarray(t.mu); mu0 = np.asarray(t.anchor)
    if day_index != t.day_index:
        t.day_index = day_index; t.day_start_mu = mu.tolist()
    R = p.region_radius if t.radius is None else t.radius
    CAP = p.daily_cap if t.cap is None else t.cap
    step = p.eta * (z - mu)
    if t.last_step is not None:
        ls = np.asarray(t.last_step)
        cos = float(step @ ls / (np.linalg.norm(step) * np.linalg.norm(ls) + 1e-12))
        if cos > p.kappa:
            return False, f"angular screen: consecutive steps collinear (cos={cos:.3f} > {p.kappa})"
    prop = mu + step
    # alternating projection onto (lifetime ball around mu0) ∩ (daily ball around day_start_mu)
    ds = np.asarray(t.day_start_mu)
    for _ in range(8):
        dv = prop - mu0; nr = np.linalg.norm(dv)
        if nr > R: prop = mu0 + dv * (R / nr)
        dd = prop - ds; nd = np.linalg.norm(dd)
        if nd > CAP: prop = ds + dd * (CAP / nd)
    dv = prop - mu0; nr = np.linalg.norm(dv)
    if nr > R: prop = mu0 + dv * (R / nr)
    binding = []
    if np.linalg.norm(prop - mu0) >= R - 1e-6: binding.append("trust region")
    if np.linalg.norm(prop - ds) >= CAP - 1e-6: binding.append("daily cap")
    t.last_step = (prop - mu).tolist(); t.mu = prop.tolist()
    return True, "updated" + (f" (binding: {', '.join(binding)})" if binding else "")


def certified_far_bound_note(t: ModalityTemplate, p: Params) -> dict:
    """Quantities of SABA Proposition 1 for this template (z-space, distance units)."""
    return {"anchor_to_profile": float(np.linalg.norm(np.asarray(t.mu) - np.asarray(t.anchor))),
            "region_radius": p.region_radius,
            "accept_radius": t.g_med + t.tau * t.g_mad}


def session_risk(A: float | None, cusum: float, bound: float) -> float:
    """Session risk in [0,1]: low only when accumulated assurance is high AND the takeover statistic is
    far from its bound.  R = 1 - A (1 - min(1, S/h)); before any evidence R = min(1, S/h)."""
    c = min(1.0, cusum / bound) if bound > 0 else 1.0
    return c if A is None else 1.0 - A * (1.0 - c)


# ----------------------------------------------------------------- session state machine
TRUSTED, STEP_UP, RESTRICTED, ABSTAIN, DENIED = "TRUSTED", "STEP_UP", "RESTRICTED", "INSUFFICIENT_EVIDENCE", "DENIED"


@dataclass
class Session:
    user: str
    templates: dict
    params: Params = field(default_factory=Params)
    recent: list = field(default_factory=list)       # (modality, s, conf, z)
    pending: list = field(default_factory=list)      # windows awaiting verified label
    cusum: float = 0.0
    state: str = ABSTAIN
    stepup_failures: int = 0
    versions: list = field(default_factory=list)
    log: list = field(default_factory=list)
    featurize: object = None    # callable(modality, events) -> vector; None = window statistics

    def __post_init__(self):
        self.snapshot("enrolment (anchor)")

    def snapshot(self, reason: str):
        self.versions.append({"version": len(self.versions) + 1, "reason": reason, "time": time.time(),
                              "templates": {m: copy.deepcopy(asdict(t)) for m, t in self.templates.items()}})

    def restore(self, version: int):
        snap = next(v for v in self.versions if v["version"] == version)
        self.templates = {m: ModalityTemplate(**copy.deepcopy(d)) for m, d in snap["templates"].items()}
        self.snapshot(f"rollback to v{version}")

    def assurance(self) -> float | None:
        if not self.recent: return None
        last = self.recent[-self.params.K:]
        # evidence accumulation: mean threshold-centred margin over the last K gated windows (P8)
        return confidence(float(np.mean([r[4] for r in last])), 0.0)

    def observe(self, modality: str, events: list[dict], day_index: int = 0, high_risk: bool = False) -> dict:
        p = self.params; t0 = time.perf_counter()
        out = {"modality": modality, "n_events": len(events)}
        if modality not in self.templates:
            out.update(decision="ignored", reason="modality not enrolled"); return out
        if len(events) < MIN_EVENTS[modality]:
            out.update(decision=ABSTAIN, reason=f"evidence gate: {len(events)} < {MIN_EVENTS[modality]} events")
            self.log.append(out); return out
        t = self.templates[modality]
        vec = self.featurize(modality, events) if self.featurize else window_vector(events, modality)
        s, z = t.score(vec, p)
        conf = confidence(s, t.tau)
        self.recent.append((modality, s, conf, z.tolist(), s - t.tau))
        self.cusum = max(0.0, self.cusum + llr(s, p, t.imp_shift))
        A = self.assurance()
        bound = min(tt.cusum_bound for tt in self.templates.values())
        if self.cusum >= bound:
            state = STEP_UP
        elif len(self.recent) < 3:
            state = ABSTAIN                    # still accumulating evidence (P8 evidence budget)
        elif A < p.stepup_level:
            state = STEP_UP
        elif high_risk and A < p.high_risk_level:
            state = RESTRICTED
        elif A >= p.trust_level and len(self.recent) >= min(p.K, 3):
            state = TRUSTED
        else:
            state = ABSTAIN if len(self.recent) < 3 else TRUSTED if A >= p.trust_level else STEP_UP
        self.state = state
        # update decision (separate from access decision)
        upd = "not admitted"
        if state == TRUSTED and s <= t.tau_g:
            ok, why = saba_update(t, z, p, day_index); upd = ("silent, " if ok else "rejected: ") + why
        elif state in (STEP_UP, RESTRICTED):
            self.pending.append((modality, z.tolist()))
            upd = "held pending verified label"
        risk = session_risk(A, self.cusum, bound)
        out.update(score=round(s, 3), confidence=round(conf, 3), assurance=round(A, 3),
                   cusum=round(self.cusum, 3), cusum_bound=round(bound, 3), decision=state,
                   risk=round(risk, 3), takeover=bool(self.cusum >= bound),
                   update=upd, latency_ms=round((time.perf_counter() - t0) * 1000, 3))
        self.log.append(out)
        return out

    def step_up(self, success: bool, day_index: int = 0) -> dict:
        if success:
            n = 0
            for m, z in self.pending:
                ok, _ = saba_update(self.templates[m], np.asarray(z), self.params, day_index); n += ok
            self.pending.clear(); self.cusum = 0.0; self.recent = []
            self.stepup_failures = 0; self.state = TRUSTED
            self.snapshot(f"verified-label update ({n} windows)")
            res = {"decision": TRUSTED, "verified_updates": n}
        else:
            self.stepup_failures += 1; self.pending.clear()
            # roll back silent updates made since the last verified version (poisoning recovery)
            verified = [v for v in self.versions if v["reason"].startswith(("enrolment", "verified"))]
            self.restore(verified[-1]["version"])
            self.state = DENIED if self.stepup_failures >= 2 else STEP_UP
            res = {"decision": self.state, "rolled_back_to": verified[-1]["version"]}
        self.log.append({"event": "step_up", **res}); return res
