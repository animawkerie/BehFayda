"""BehFayda reference service (research prototype; NOT connected to Fayda/NIDP).

Run:  uvicorn behfayda.app:app --host 0.0.0.0 --port 8000   (serves the web app at /)

Components (Chapter 8):
  /mock-idp/*      simulated eSignet-style OIDC identity provider (stands in for Fayda login; no real data)
  /v1/consent      purpose-bound consent per modality
  /v1/enrol        behavioural enrolment (window vectors only; raw events never stored)
  /v1/sessions     continuous authentication: windows in, assurance decisions out
  /v1/rp/assurance relying-party view: <level, confidence, coverage, latency> only
  /v1/profiles     versioned profiles, rollback
  /v1/privacy      epsilon ledger for DP-trained background models
  /v1/audit        append-only, hash-chained audit log
  DELETE /v1/users erasure (Personal Data Protection Proclamation No. 1321/2024 right to erasure)
  /v1/bench/*      benchmark tool: collect labelled windows from several participants, run the
                   leakage-safe benchmark (deep encoder vs window statistics), export the data
  /v1/sessions/{sid}/logout  enforced logout (takeover alarm or denied step-up), audited
  /v1/model        the deployable BehEnc-MLP encoder weights (also inlined into the web app)
"""
from __future__ import annotations
import os, json, time, hmac, hashlib, base64, secrets, sqlite3, threading
from dataclasses import asdict
import numpy as np
from fastapi import FastAPI, HTTPException, Header
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from .core import (Session, ModalityTemplate, Params, enrol, enrol_deep, window_vector, MIN_EVENTS, WINDOW_EVENTS,
                   certified_far_bound_note)
from .encoder import Encoder
from . import bench
from .privacy import PrivacyLedger

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
FRONT = os.environ.get("BEHFAYDA_FRONTEND", os.path.join(os.path.dirname(ROOT), "frontend"))
DB = os.environ.get("BEHFAYDA_DB", os.path.join(ROOT, "behfayda.sqlite"))
SECRET = os.environ.get("BEHFAYDA_SECRET", secrets.token_hex(32)).encode()
BACKGROUND = json.load(open(os.path.join(ROOT, "data", "background.json")))["modalities"]
MODEL_PATH = os.environ.get("BEHFAYDA_MODEL", os.path.join(os.path.dirname(ROOT), "models", "behenc_mlp_v1.json"))
ENCODER = Encoder(MODEL_PATH) if os.path.exists(MODEL_PATH) else None

app = FastAPI(title="BehFayda reference service", version="2.0.0-research")
_lock = threading.Lock()
SESSIONS: dict[str, Session] = {}
ENROL_BUF: dict[str, dict[str, list]] = {}
RAW_BUF: dict[str, dict[str, list]] = {}
LEDGERS: dict[str, PrivacyLedger] = {}


# ------------------------------------------------------------------ storage + audit
def db():
    c = sqlite3.connect(DB); c.execute("pragma journal_mode=wal")
    c.execute("create table if not exists consent(user text, modality text, granted int, ts real, primary key(user, modality))")
    c.execute("create table if not exists profile(user text primary key, templates text, ts real)")
    c.execute("create table if not exists sample(id integer primary key autoincrement, participant text, modality text, "
              "phase text, ts real, events text)")
    c.execute("create table if not exists audit(seq integer primary key autoincrement, ts real, actor text, action text, detail text, prev text, hash text)")
    return c


def audit(actor: str, action: str, detail: dict):
    with _lock, db() as c:
        row = c.execute("select hash from audit order by seq desc limit 1").fetchone()
        prev = row[0] if row else "genesis"
        body = json.dumps({"ts": time.time(), "actor": actor, "action": action, "detail": detail}, sort_keys=True)
        h = hashlib.sha256((prev + body).encode()).hexdigest()
        c.execute("insert into audit(ts, actor, action, detail, prev, hash) values(?,?,?,?,?,?)",
                  (time.time(), actor, action, json.dumps(detail), prev, h))


# ------------------------------------------------------------------ mock OIDC IdP (HS256 JWT)
def _b64(b: bytes) -> str: return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def issue_token(sub: str, acr: str = "mosip:idp:acr:generated-code") -> str:
    head = _b64(json.dumps({"alg": "HS256", "typ": "JWT"}).encode())
    body = _b64(json.dumps({"iss": "mock-esignet-idp", "sub": sub, "aud": "behfayda-demo-rp",
                            "acr": acr, "iat": int(time.time()), "exp": int(time.time()) + 3600}).encode())
    sig = _b64(hmac.new(SECRET, f"{head}.{body}".encode(), hashlib.sha256).digest())
    return f"{head}.{body}.{sig}"


def verify_token(tok: str) -> dict:
    try:
        head, body, sig = tok.split(".")
        good = _b64(hmac.new(SECRET, f"{head}.{body}".encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(good, sig): raise ValueError("signature")
        claims = json.loads(base64.urlsafe_b64decode(body + "=" * (-len(body) % 4)))
        if claims["exp"] < time.time(): raise ValueError("expired")
        return claims
    except Exception as e:
        raise HTTPException(401, f"invalid identity token: {e}")


def pseudonym(sub: str) -> str:
    """Pairwise pseudonymous identifier: the service never stores the identity number itself."""
    return hmac.new(SECRET, b"pairwise|" + sub.encode(), hashlib.sha256).hexdigest()[:24]


class LoginReq(BaseModel):
    demo_id: str = Field(..., description="Demo identifier typed by the user (NOT a real Fayda number)")
    pin: str


@app.post("/mock-idp/login")
def mock_login(r: LoginReq):
    if len(r.pin) < 4: raise HTTPException(401, "PIN must be 4+ digits (simulation)")
    sub = hashlib.sha256(("demo|" + r.demo_id + "|" + r.pin).encode()).hexdigest()
    tok = issue_token(sub); audit("idp", "login", {"user": pseudonym(sub)})
    return {"id_token": tok, "note": "simulated eSignet-style OIDC login; not connected to Fayda"}


def user_of(authorization: str | None) -> str:
    if not authorization or not authorization.startswith("Bearer "): raise HTTPException(401, "missing bearer token")
    return pseudonym(verify_token(authorization[7:])["sub"])


# ------------------------------------------------------------------ consent
class ConsentReq(BaseModel):
    modalities: dict[str, bool]


@app.post("/v1/consent")
def consent(r: ConsentReq, authorization: str | None = Header(None)):
    u = user_of(authorization)
    with db() as c:
        for m, g in r.modalities.items():
            c.execute("insert or replace into consent values(?,?,?,?)", (u, m, int(g), time.time()))
    audit(u, "consent", r.modalities); return {"user": u, "consent": r.modalities}


def consented(u: str) -> set[str]:
    with db() as c:
        return {m for m, g in c.execute("select modality, granted from consent where user=?", (u,)) if g}


# ------------------------------------------------------------------ enrolment
class WindowReq(BaseModel):
    modality: str
    events: list[dict]
    day_index: int = 0     # ignored unless BEHFAYDA_CLIENT_DAY=1 (testing): SABA's daily cap needs a trusted server clock
    high_risk: bool = False


@app.post("/v1/enrol/windows")
def enrol_window(r: WindowReq, authorization: str | None = Header(None)):
    u = user_of(authorization)
    if r.modality not in consented(u): raise HTTPException(403, f"no consent for {r.modality}")
    if len(r.events) < MIN_EVENTS[r.modality]: return {"accepted": False, "reason": "evidence gate"}
    ENROL_BUF.setdefault(u, {}).setdefault(r.modality, []).append(window_vector(r.events, r.modality))
    RAW_BUF.setdefault(u, {}).setdefault(r.modality, []).append(r.events)   # in memory only, until finalize
    return {"accepted": True, "windows": {m: len(v) for m, v in ENROL_BUF[u].items()}}


@app.post("/v1/enrol/finalize")
def enrol_finalize(mode: str = "deep", authorization: str | None = Header(None)):
    """mode=deep: BehEnc-MLP embeddings + cosine template (best deployable benchmark model);
    mode=stats: window statistics (prototype v1)."""
    u = user_of(authorization); buf = ENROL_BUF.get(u, {})
    tpls = {}
    for m, ws in buf.items():
        if len(ws) >= 4:
            if mode == "deep" and ENCODER is not None and m in ENCODER.m["modalities"]:
                tpls[m] = enrol_deep(m, [ENCODER.embedding(ev, m) for ev in RAW_BUF[u][m]], Params())
            else:
                bg = [np.asarray(v) for v in BACKGROUND[m]] if m in BACKGROUND else None
                tpls[m] = enrol(m, ws, Params(), background=bg)
    if not tpls: raise HTTPException(400, "not enough enrolment windows (need >= 4 per modality)")
    with db() as c:
        c.execute("insert or replace into profile values(?,?,?)", (u, json.dumps({m: asdict(t) for m, t in tpls.items()}), time.time()))
    LEDGERS[u] = PrivacyLedger()
    ENROL_BUF.pop(u, None); RAW_BUF.pop(u, None)
    audit(u, "enrol", {m: t.n_enrol for m, t in tpls.items()})
    return {"enrolled": {m: {"windows": t.n_enrol, "mode": "deep (BehEnc-MLP, cosine)" if t.kind == "deep" else
                             "background-cohort logistic" if t.weights else "one-class"} for m, t in tpls.items()}}


def load_templates(u: str) -> dict:
    with db() as c:
        row = c.execute("select templates from profile where user=?", (u,)).fetchone()
    if not row: raise HTTPException(404, "not enrolled")
    return {m: ModalityTemplate(**d) for m, d in json.loads(row[0]).items()}


# ------------------------------------------------------------------ continuous authentication
@app.post("/v1/sessions")
def start_session(authorization: str | None = Header(None)):
    u = user_of(authorization); sid = secrets.token_urlsafe(12)
    tpls = load_templates(u)
    feat = None
    if ENCODER is not None and any(t.kind == "deep" for t in tpls.values()):
        feat = lambda m, ev: ENCODER.embedding(ev, m) if tpls[m].kind == "deep" else window_vector(ev, m)
    SESSIONS[sid] = Session(u, tpls, featurize=feat); audit(u, "session_start", {"sid": sid})
    return {"session_id": sid}


def sess(sid: str) -> Session:
    if sid not in SESSIONS: raise HTTPException(404, "unknown session")
    return SESSIONS[sid]


@app.post("/v1/sessions/{sid}/windows")
def observe(sid: str, r: WindowReq):
    s = sess(sid)
    if r.modality not in consented(s.user): raise HTTPException(403, f"no consent for {r.modality}")
    day = r.day_index if os.environ.get("BEHFAYDA_CLIENT_DAY") == "1" else int(time.time() // 86400)
    out = s.observe(r.modality, r.events, day, r.high_risk)
    if out.get("update", "").startswith("silent"):
        _persist(s)
    audit(s.user, "decision", {k: out.get(k) for k in ("modality", "decision", "assurance", "update")})
    return out


class StepUp(BaseModel):
    id_token: str | None = None   # a fresh token from the IdP = successful step-up


@app.post("/v1/sessions/{sid}/stepup")
def stepup(sid: str, r: StepUp):
    s = sess(sid); ok = False
    if r.id_token:
        try: ok = pseudonym(verify_token(r.id_token)["sub"]) == s.user
        except HTTPException: ok = False
    res = s.step_up(ok); _persist(s)
    audit(s.user, "step_up", {"success": ok, **{k: v for k, v in res.items() if k != 'decision'}})
    return {"success": ok, **res}


def _persist(s: Session):
    with db() as c:
        c.execute("insert or replace into profile values(?,?,?)", (s.user, json.dumps({m: asdict(t) for m, t in s.templates.items()}), time.time()))


@app.get("/v1/rp/assurance/{sid}")
def rp_assurance(sid: str):
    """What a relying party (bank, e-government portal) receives: no features, no scores history."""
    s = sess(sid); A = s.assurance()
    gated = [e for e in s.log if "decision" in e and "n_events" in e]
    cov = (sum(1 for e in gated if e["decision"] != "INSUFFICIENT_EVIDENCE") / len(gated)) if gated else 0.0
    lat = [e["latency_ms"] for e in gated if "latency_ms" in e]
    return {"assurance_state": s.state, "confidence": None if A is None else round(A, 3),
            "window_coverage": round(cov, 3), "median_latency_ms": float(np.median(lat)) if lat else None,
            "acr_hint": "behavioural-session-assurance (research)"}


@app.get("/v1/profiles/versions/{sid}")
def versions(sid: str):
    s = sess(sid)
    return [{"version": v["version"], "reason": v["reason"], "time": v["time"]} for v in s.versions] + \
           [{"saba": {m: certified_far_bound_note(t, s.params) for m, t in s.templates.items()}}]


@app.post("/v1/profiles/rollback/{sid}/{version}")
def rollback(sid: str, version: int):
    s = sess(sid); s.restore(version); _persist(s); audit(s.user, "rollback", {"to": version})
    return {"rolled_back_to": version}


@app.get("/v1/privacy/{sid}")
def privacy(sid: str):
    s = sess(sid); L = LEDGERS.setdefault(s.user, PrivacyLedger())
    return {"epsilon_spent": round(L.eps, 3), "epsilon_max": L.eps_max, "delta": L.delta,
            "remaining_dp_updates": L.remaining_updates(), "accountant": "RDP (dp_accounting), Poisson-subsampled Gaussian"}


@app.get("/v1/audit")
def audit_log(limit: int = 50):
    with db() as c:
        rows = c.execute("select seq, ts, actor, action, detail, hash from audit order by seq desc limit ?", (limit,)).fetchall()
    return [dict(zip(("seq", "ts", "actor", "action", "detail", "hash"), r)) for r in rows]


@app.get("/v1/audit/verify")
def audit_verify():
    with db() as c:
        rows = c.execute("select ts, actor, action, detail, prev, hash from audit order by seq").fetchall()
    prev = "genesis"
    for i, (ts, actor, action, detail, p, h) in enumerate(rows):
        if p != prev: return {"intact": False, "broken_at": i}
        prev = h
    return {"intact": True, "entries": len(rows)}


@app.delete("/v1/users/me")
def erase(authorization: str | None = Header(None)):
    u = user_of(authorization)
    with db() as c:
        c.execute("delete from profile where user=?", (u,)); c.execute("delete from consent where user=?", (u,))
    for k in [k for k, v in SESSIONS.items() if v.user == u]: SESSIONS.pop(k)
    LEDGERS.pop(u, None); audit(u, "erasure", {}); return {"erased": True}


class LogoutReq(BaseModel):
    reason: str = "takeover alarm"


@app.post("/v1/sessions/{sid}/logout")
def forced_logout(sid: str, r: LogoutReq):
    """Enforced logout: the session is revoked; the relying party must start a new IdP login."""
    s = sess(sid); SESSIONS.pop(sid, None)
    audit(s.user, "forced_logout", {"sid": sid, "reason": r.reason, "cusum": round(s.cusum, 3), "state": s.state})
    return {"logged_out": True, "reason": r.reason}


# ------------------------------------------------------------------ benchmark tool
class SampleReq(BaseModel):
    participant: str = Field(..., description="benchmark pseudonym, e.g. P01 (never a real identity)")
    modality: str
    phase: str = Field("enrol", pattern="^(enrol|test)$")
    events: list[dict]


@app.post("/v1/bench/samples")
def bench_add(r: SampleReq):
    if r.modality not in WINDOW_EVENTS: raise HTTPException(400, "unknown modality")
    if len(r.events) < MIN_EVENTS[r.modality]: return {"accepted": False, "reason": "evidence gate"}
    keep = {"tap": ["duration_ms", "move_x", "move_y", "off_x", "off_y"], "key": ["hold_ms", "flight_ms", "inter_ms"],
            "swipe": ["duration_ms", "distance", "speed", "straightness"]}[r.modality]
    ev = [{k: e.get(k) for k in keep} for e in r.events]      # timing / geometry only; no content, no coordinates
    with db() as c:
        c.execute("insert into sample(participant, modality, phase, ts, events) values(?,?,?,?,?)",
                  (r.participant, r.modality, r.phase, time.time(), json.dumps(ev)))
        n = c.execute("select count(*) from sample where participant=? and modality=?", (r.participant, r.modality)).fetchone()[0]
    return {"accepted": True, "windows": n}


def _samples():
    with db() as c:
        rows = c.execute("select participant, modality, phase, ts, events from sample").fetchall()
    return [{"participant": p, "modality": m, "phase": ph, "ts": ts, "events": json.loads(e)} for p, m, ph, ts, e in rows]


@app.get("/v1/bench/samples")
def bench_export():
    S = _samples()
    return {"n": len(S), "participants": sorted({s["participant"] for s in S}), "samples": S}


@app.post("/v1/bench/run")
def bench_run(modalities: str = "tap,key,swipe"):
    S = _samples(); res = {m: bench.run(S, m, ENCODER) for m in modalities.split(",")}
    audit("bench", "benchmark_run", {m: r["summary"] for m, r in res.items()}); return res


@app.delete("/v1/bench/samples")
def bench_clear():
    with db() as c: c.execute("delete from sample")
    audit("bench", "benchmark_data_erased", {}); return {"erased": True}


@app.get("/v1/model")
def model():
    if ENCODER is None: raise HTTPException(404, "encoder not installed (run backend/scripts/train_deploy.py)")
    return JSONResponse(ENCODER.m)


@app.get("/v1/health")
def health(): return {"status": "ok", "version": app.version, "encoder": None if ENCODER is None else ENCODER.m.get("name")}


@app.get("/api/background")
def background(): return JSONResponse(BACKGROUND)


if os.path.isdir(FRONT):
    app.mount("/static", StaticFiles(directory=FRONT), name="static")

    @app.get("/")
    def index(): return FileResponse(os.path.join(FRONT, "index.html"))
