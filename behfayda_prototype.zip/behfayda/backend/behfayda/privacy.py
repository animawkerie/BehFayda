"""Privacy ledger and unit-level DP-SGD for the background verifier (after P7).

* PrivacyLedger: per-template epsilon accounting with the dp_accounting RDP accountant for the
  Poisson-subsampled Gaussian mechanism; refuses updates that would exceed eps_max.
* dp_sgd_logistic: unit-level DP-SGD (per-unit clipping to C, Gaussian noise sigma*C).
The tests check the accountant against P7's published Table III (q=0.2, sigma=3, delta=1e-5).
"""
from __future__ import annotations
import numpy as np

try:
    import dp_accounting
    from dp_accounting import rdp
except Exception:  # pragma: no cover
    dp_accounting = None


def epsilon(steps: int, q: float = 0.2, sigma: float = 3.0, delta: float = 1e-5) -> float:
    if dp_accounting is None:
        raise RuntimeError("dp_accounting not installed")
    acc = rdp.RdpAccountant()
    ev = dp_accounting.SelfComposedDpEvent(
        dp_accounting.PoissonSampledDpEvent(q, dp_accounting.GaussianDpEvent(sigma)), steps)
    acc.compose(ev)
    return float(acc.get_epsilon(delta))


class PrivacyLedger:
    def __init__(self, eps_max: float = 8.0, q: float = 0.2, sigma: float = 3.0, delta: float = 1e-5,
                 enrol_steps: int = 150, update_steps: int = 25):
        self.eps_max, self.q, self.sigma, self.delta = eps_max, q, sigma, delta
        self.update_steps = update_steps
        self.steps = enrol_steps
        self.history = [("enrolment", enrol_steps, self.eps)]

    @property
    def eps(self) -> float:
        return epsilon(self.steps, self.q, self.sigma, self.delta)

    def can_update(self) -> bool:
        return epsilon(self.steps + self.update_steps, self.q, self.sigma, self.delta) <= self.eps_max

    def charge_update(self) -> float:
        if not self.can_update():
            raise PermissionError("privacy budget exhausted: re-enrolment required")
        self.steps += self.update_steps
        self.history.append(("update", self.steps, self.eps))
        return self.eps

    def remaining_updates(self) -> int:
        n, s = 0, self.steps
        while epsilon(s + self.update_steps, self.q, self.sigma, self.delta) <= self.eps_max:
            s += self.update_steps; n += 1
        return n


def dp_sgd_logistic(units: list[tuple[np.ndarray, np.ndarray]], steps: int, q=0.2, sigma=3.0, C=1.0,
                    lr=0.5, l2=1e-3, seed=0):
    """units: list of (X_u, y_u). Returns weights. Bias via appended 1-column."""
    rng = np.random.default_rng(seed)
    d = units[0][0].shape[1] + 1
    w = np.zeros(d); N = len(units)
    for _ in range(steps):
        mask = rng.random(N) < q
        g_sum = np.zeros(d)
        for (X, y), m in zip(units, mask):
            if not m: continue
            Xb = np.hstack([X, np.ones((len(X), 1))])
            p = 1 / (1 + np.exp(-Xb @ w))
            g = ((p - y)[:, None] * Xb).mean(0)
            n = np.linalg.norm(g)
            g_sum += g * min(1.0, C / (n + 1e-12))
        noise = rng.normal(0, sigma * C, d)
        w -= lr * ((g_sum + noise) / (q * N) + l2 * w)
    return w
