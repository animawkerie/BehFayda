"""NumPy forward pass of the exported BehEnc-MLP encoder (parity reference for frontend/encoder.js).

embedding(events, modality) maps one window of behavioural events to a unit-norm 128-d vector:
  per-event features -> signed log on heavy-tailed columns -> standardise (model or local capture-domain
  statistics) -> clip to +-5 -> window statistics (mean, std, p25, median, p75) -> MLP -> L2 normalise.
"""
from __future__ import annotations
import json, math
import numpy as np


def _arr(v):
    """weights are stored either as nested lists or as {'shape', 'f32': base64 little-endian float32}."""
    if isinstance(v, dict) and 'f32' in v:
        import base64
        return np.frombuffer(base64.b64decode(v['f32']), dtype='<f4').astype(float).reshape(v['shape'])
    return np.asarray(v, float)


def _gelu(x):  # flax nn.gelu default (tanh approximation)
    return 0.5 * x * (1.0 + np.tanh(math.sqrt(2.0 / math.pi) * (x + 0.044715 * x ** 3)))


def _ln(x, p, eps=1e-6):
    m = x.mean(-1, keepdims=True); v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / np.sqrt(v + eps) * _arr(p['scale']) + _arr(p['bias'])


def _dense(x, p):
    return x @ _arr(p['kernel']) + _arr(p['bias'])


class Encoder:
    def __init__(self, path_or_dict):
        self.m = json.load(open(path_or_dict)) if isinstance(path_or_dict, str) else path_or_dict

    def features(self, events, modality):
        spec = self.m['modalities'][modality]
        X = np.array([[np.nan if e.get(c) is None else float(e.get(c)) for c in spec['features']] for e in events], float)
        for j, lg in enumerate(spec['log_transform']):
            if lg: X[:, j] = np.sign(X[:, j]) * np.log1p(np.abs(X[:, j]))
        return X

    def normalise(self, X, modality, local=None):
        spec = self.m['modalities'][modality]
        mu, sd = (np.asarray(spec['mu']), np.asarray(spec['sd'])) if local is None else local
        return np.clip(np.nan_to_num((X - mu) / sd), -spec['clip'], spec['clip'])

    @staticmethod
    def stats(Xn):
        return np.concatenate([Xn.mean(0), Xn.std(0), np.percentile(Xn, 25, 0), np.median(Xn, 0), np.percentile(Xn, 75, 0)])

    def embed_matrix(self, Xn, modality):
        p = self.m['modalities'][modality]['params']
        h = self.stats(Xn)
        h = _gelu(_ln(_dense(h, p['dense0']), p['ln0']))
        h = _gelu(_ln(_dense(h, p['dense1']), p['ln1']))
        e = _dense(h, p['dense2'])
        return e / (np.linalg.norm(e) + 1e-6)

    def embedding(self, events, modality, local=None):
        return self.embed_matrix(self.normalise(self.features(events, modality), modality, local), modality)

    def local_stats(self, windows, modality):
        """capture-domain standardisation from raw event windows collected on this deployment."""
        X = np.vstack([self.features(w, modality) for w in windows])
        return np.nanmean(X, 0), np.nanstd(X, 0) + 1e-6
