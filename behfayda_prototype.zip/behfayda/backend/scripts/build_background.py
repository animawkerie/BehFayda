"""Build the background cohort (window vectors) shipped with the prototype.

Source: public BahriApp-Dataset (CC BY 4.0). Only window-level feature vectors are kept; no participant
identifiers, timestamps or raw events leave this script. Tap and English keystroke only, because their
feature definitions are reproducible in a browser (Section 8.7 of the dissertation explains why swipe,
whose v1.0.0 extractor was retracted, is scored one-class).
usage: python -I build_background.py <dataset_dir> <out.json>
"""
import sys, os, json
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
import numpy as np, pandas as pd
from behfayda.core import window_vector, WINDOW_EVENTS

D, out = sys.argv[1], sys.argv[2]
rng = np.random.default_rng(2026)
res = {"source": "BahriApp-Dataset (CC BY 4.0), window vectors only", "modalities": {}}

tap = pd.read_csv(f"{D}/Tap_Data.csv"); a = np.sqrt(tap['_targetSizeAre'])
tev = pd.DataFrame({'u': tap['id'], 'r': tap['id'].astype(str) + tap['startTime'], 't': tap['startTime'],
                    'duration_ms': tap['TapDuration'], 'move_x': tap['TapLocalMovementX'],
                    'move_y': tap['TapLocalMovementY'], 'off_x': tap['TapInitialLocalLocationX'] / a - 0.5,
                    'off_y': tap['TapInitialLocalLocationY'] / a - 0.5})
ks = pd.read_csv(f"{D}/Keystroke_Data_English.csv")
ks = ks[(ks.holdTime > 0) & (ks.holdTime < 2000)]
kev = pd.DataFrame({'u': ks['id'], 'r': ks['id'].astype(str) + ks['sessionId'].astype(str), 't': ks['TimeStamp'],
                    'hold_ms': ks['holdTime'], 'flight_ms': ks['flightTime'].where((ks.flightTime >= 0) & (ks.flightTime <= 5000))})
for mod, ev in (('tap', tev), ('key', kev)):
    W = WINDOW_EVENTS[mod]; vecs = []
    for _, g in ev.sort_values('t').groupby(['u', 'r'], sort=False):
        rec = g.to_dict('records')
        for k in range(len(rec) // W):
            vecs.append(window_vector(rec[k * W:(k + 1) * W], mod))
    V = np.vstack(vecs)
    sel = rng.choice(len(V), min(1200, len(V)), replace=False)
    res['modalities'][mod] = np.round(V[sel], 4).tolist()
    print(mod, V.shape, '->', len(sel))
json.dump(res, open(out, 'w'))
print('bytes', os.path.getsize(out))
