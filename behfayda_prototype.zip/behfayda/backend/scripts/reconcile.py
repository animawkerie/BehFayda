"""Reconciled BahriApp verification baseline (Phase 3).

One protocol for every modality, chosen from the most rigorous published report (P3, Feature Scope):
  * evidence unit  : non-overlapping windows of W events inside one session/round
  * split unit     : sitting = a user's sessions separated by < 30 min (strictest; prevents
                     same-sitting rounds landing on both sides of a temporal split)
  * protocol D     : earliest 60% of each user's sittings enrol, the rest test
  * impostors      : protocol-consistent and UNSEEN (impostor users split per target into
                     disjoint train / test pools)
  * features       : 'safe'  = event-scope behavioural columns that pass an automatic scope audit
                               (not constant within session, not constant within user, no
                               duplicates, no ids / timestamps / screen positions)
                     'full'  = every numeric column (reproduces the inflated regime)
  * protocol A     : random-row split, 'full' features (diagnostic contrast only)
Classifier: random forest, one-vs-rest per user, balanced class weights, 3 seeds.
"""
import sys, json, os
import numpy as np, pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_curve

D = sys.argv[1]; OUT = sys.argv[2]
os.makedirs(OUT, exist_ok=True)
GAP = 30 * 60  # seconds

def eer(y, s):
    fpr, tpr, _ = roc_curve(y, s)
    fnr = 1 - tpr
    i = np.nanargmin(np.abs(fnr - fpr))
    return float((fpr[i] + fnr[i]) / 2)

def to_sec(series):
    t = pd.to_datetime(series, errors='coerce')
    return (t - pd.Timestamp('1970-01-01')).dt.total_seconds()

def load(mod):
    if mod == 'tap':
        df = pd.read_csv(f'{D}/Tap_Data.csv')
        df['sess'] = df['id'].astype(str) + '|' + df['startTime'].astype(str)
        df['t'] = to_sec(df['startTime'])
        df['offX'] = df['TapInitialLocalLocationX'] / np.sqrt(df['_targetSizeAre'])
        df['offY'] = df['TapInitialLocalLocationY'] / np.sqrt(df['_targetSizeAre'])
        safe = ['TapDuration', 'TapLocalMovementX', 'TapLocalMovementY', 'offX', 'offY']
    elif mod == 'swipe':
        df = pd.read_csv(f'{D}/Swipe_Data.csv')
        df['sess'] = df['id'].astype(str) + '|' + df['sessionId'].astype(str)
        df['t'] = df['startTime'].astype(float)
        safe = ['duration', 'speed', 'acceleration', 'jerk', 'distance', 'movementVariability',
                'straightness', 'angle', 'areaCoverage']
    elif mod in ('ks_en', 'ks_am', 'ks_pw'):
        f = {'ks_en': 'Keystroke_Data_English.csv', 'ks_am': 'Keystroke_Data_Amharic.csv',
             'ks_pw': 'Keystroke_PasswordText_Data.csv'}[mod]
        df = pd.read_csv(f'{D}/{f}')
        df['sess'] = df['id'].astype(str) + '|' + df['sessionId'].astype(str)
        df['t'] = to_sec(df['TimeStamp'])
        df = df[(df['holdTime'] > 0) & (df['holdTime'] < 2000)]
        df.loc[(df['flightTime'] < 0) | (df['flightTime'] > 5000), 'flightTime'] = np.nan
        df.loc[(df['interKeyTime'] < 0) | (df['interKeyTime'] > 5000), 'interKeyTime'] = np.nan
        safe = ['holdTime', 'flightTime', 'interKeyTime']
    elif mod == 'gyro':
        df = pd.read_csv(f'{D}/Gyroscope_Data.csv')
        df['sess'] = df['id'].astype(str) + '|' + df['sessionId'].astype(str)
        df['t'] = to_sec(df['timestamp'])
        safe = ['gyroX', 'gyroY', 'gyroZ', 'jerk', 'tiltAcceleration', 'tiltSpeed',
                'rotationDuration', 'rotationDirectionConsistency']
    df['user'] = df['id'].astype(str)
    drop = {'id', 'sessionId', 'user', 'sess', 't', 'TapPressTime', 'TapReleaseTime', 'pressTime',
            'releaseTime', 'startTime', 'endTime', 'offX', 'offY'}
    full = [c for c in df.columns if c not in drop and pd.api.types.is_numeric_dtype(df[c])]
    return df, safe, full

def scope_audit(df, cols, tau=0.95):
    """Drop columns constant within session or within user for >= tau of groups (P3-style)."""
    kept, report = [], {}
    for c in cols:
        s_const = (df.groupby('sess')[c].nunique(dropna=True) <= 1).mean()
        u_const = (df.groupby('user')[c].nunique(dropna=True) <= 1).mean()
        report[c] = (round(float(s_const), 3), round(float(u_const), 3))
        if s_const < tau and u_const < tau:
            kept.append(c)
    # exact duplicates
    out = []
    for c in kept:
        if not any(df[c].equals(df[o]) for o in out):
            out.append(c)
    return out, report

def windows(df, cols, W):
    rows = []
    for (u, s), g in df.sort_values(['t']).groupby(['user', 'sess'], sort=False):
        n = len(g) // W
        X = g[cols].to_numpy(float)
        for k in range(n):
            blk = X[k * W:(k + 1) * W]
            feats = np.concatenate([np.nanmean(blk, 0), np.nanstd(blk, 0),
                                    np.nanpercentile(blk, 25, 0), np.nanmedian(blk, 0),
                                    np.nanpercentile(blk, 75, 0)])
            rows.append((u, s, g['t'].iloc[k * W], feats))
    if not rows:
        return None
    U = np.array([r[0] for r in rows]); S = np.array([r[1] for r in rows])
    T = np.array([r[2] for r in rows], float); X = np.vstack([r[3] for r in rows])
    return U, S, T, X

def sittings(U, S, T):
    """Assign sitting index per user: sessions whose start is < GAP after previous session end."""
    sit = np.empty(len(U), dtype=object)
    sess_start = pd.DataFrame({'u': U, 's': S, 't': T}).groupby(['u', 's'])['t'].min().reset_index()
    sess_start = sess_start.sort_values(['u', 't'])
    lab = {}
    for u, g in sess_start.groupby('u'):
        k, prev = 0, None
        for s, t in zip(g['s'], g['t']):
            if prev is not None and (np.isnan(t) or np.isnan(prev) or t - prev > GAP):
                k += 1
            lab[(u, s)] = k; prev = t
    for i in range(len(U)):
        sit[i] = lab[(U[i], S[i])]
    return sit.astype(int)

def run(mod, W, seeds=(1, 2, 3), K_list=(1, 5)):
    df, safe, full = load(mod)
    safe_kept, rep = scope_audit(df, safe)
    full_kept = list(dict.fromkeys(full))
    results = {}
    for fsname, cols in (('safe', safe_kept), ('full', full_kept)):
        w = windows(df, cols, W)
        U, S, T, X = w
        X = np.nan_to_num(X, nan=0.0)  # NaN only from structurally absent first flight time
        sit = sittings(U, S, T)
        users = np.unique(U)
        nsit = {u: sit[U == u].max() + 1 for u in users}
        elig = [u for u in users if nsit[u] >= 3 and (U == u).sum() >= 15]
        for proto in (('D', 'A') if fsname == 'full' else ('D',)):
            for seed in seeds:
                rng = np.random.default_rng(seed)
                for u in elig:
                    gi = np.where(U == u)[0]
                    if proto == 'D':
                        cut = max(1, int(round(0.6 * nsit[u])))
                        g_tr = gi[sit[gi] < cut]; g_te = gi[sit[gi] >= cut]
                    else:
                        p = rng.permutation(gi); c = int(0.6 * len(p)); g_tr, g_te = p[:c], p[c:]
                    if len(g_tr) < 10 or len(g_te) < 5:
                        continue
                    others = np.array([o for o in elig if o != u]); rng.shuffle(others)
                    half = len(others) // 2
                    pool_tr, pool_te = set(others[:half]), set(others[half:])
                    # protocol-consistent impostor partition: impostor train from their early sittings,
                    # impostor test from later sittings of DIFFERENT (unseen) users
                    imp_tr = [i for i in np.where(np.isin(U, list(pool_tr)))[0]
                              if proto == 'A' or sit[i] < max(1, int(round(0.6 * nsit[U[i]])))]
                    imp_te = [i for i in np.where(np.isin(U, list(pool_te)))[0]
                              if proto == 'A' or sit[i] >= max(1, int(round(0.6 * nsit[U[i]])))]
                    imp_tr = rng.choice(imp_tr, min(len(imp_tr), max(10 * len(g_tr), 500), 1500), replace=False)
                    imp_te = np.array(imp_te)
                    if len(imp_te) > 2000:
                        imp_te = rng.choice(imp_te, 2000, replace=False)
                    Xtr = np.vstack([X[g_tr], X[imp_tr]]); ytr = np.r_[np.ones(len(g_tr)), np.zeros(len(imp_tr))]
                    clf = RandomForestClassifier(150, min_samples_leaf=2, class_weight='balanced',
                                                 n_jobs=2, random_state=seed).fit(Xtr, ytr)
                    sg = clf.predict_proba(X[g_te])[:, 1]; si = clf.predict_proba(X[imp_te])[:, 1]
                    for K in K_list:
                        if K == 1:
                            a, b = sg, si
                        else:
                            # average K consecutive windows of the same identity (genuine: by time order;
                            # impostor: within each impostor user)
                            order = np.argsort(T[g_te]); a = [sg[order][j:j + K].mean() for j in range(0, len(sg) - K + 1, K)]
                            b = []
                            for o in np.unique(U[imp_te]):
                                m = U[imp_te] == o; v = si[m][np.argsort(T[imp_te][m])]
                                b += [v[j:j + K].mean() for j in range(0, len(v) - K + 1, K)]
                            a, b = np.array(a), np.array(b)
                        if len(a) < 2 or len(b) < 2:
                            continue
                        e = eer(np.r_[np.ones(len(a)), np.zeros(len(b))], np.r_[a, b])
                        results.setdefault((fsname, proto, K), {}).setdefault(u, []).append(e)
    summ = []
    rng = np.random.default_rng(0)
    for (fs, proto, K), d in results.items():
        per_user = np.array([np.mean(v) for v in d.values()])
        boots = [np.median(rng.choice(per_user, len(per_user))) for _ in range(2000)]
        summ.append(dict(modality=mod, W=W, features=fs, protocol=proto, K=K, n_users=len(per_user),
                         median_eer=round(float(np.median(per_user)), 4),
                         ci_low=round(float(np.percentile(boots, 2.5)), 4),
                         ci_high=round(float(np.percentile(boots, 97.5)), 4),
                         mean_eer=round(float(per_user.mean()), 4)))
    meta = dict(modality=mod, W=W, safe_candidates=safe, safe_kept=safe_kept, scope_report=rep,
                full_cols=full_kept)
    return summ, meta

if __name__ == '__main__':
    mods = sys.argv[3].split(',')
    Ws = dict(tap=12, swipe=5, ks_en=9, ks_am=7, ks_pw=5, gyro=3)
    allsum, allmeta = [], []
    for m in mods:
        s, meta = run(m, Ws[m])
        allsum += s; allmeta.append(meta)
        pd.DataFrame(allsum).to_csv(f'{OUT}/summary_{"_".join(mods)}.csv', index=False)
        json.dump(allmeta, open(f'{OUT}/meta_{"_".join(mods)}.json', 'w'), indent=1, default=str)
        print(pd.DataFrame(s).to_string(), flush=True)
