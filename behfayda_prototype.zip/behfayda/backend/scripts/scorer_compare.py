import sys, os, json
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
import numpy as np, pandas as pd
from sklearn.metrics import roc_curve
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from behfayda.core import window_vector
df = pd.read_csv(sys.argv[1]); df['t']=(pd.to_datetime(df['startTime'])-pd.Timestamp('1970-01-01')).dt.total_seconds()
df['user']=df['id'].astype(str); df['round']=df['user']+'|'+df['startTime'].astype(str); a=np.sqrt(df['_targetSizeAre'])
ev=pd.DataFrame({'user':df.user,'round':df['round'],'t':df.t,'duration_ms':df.TapDuration,'move_x':df.TapLocalMovementX,'move_y':df.TapLocalMovementY,'off_x':df.TapInitialLocalLocationX/a-0.5,'off_y':df.TapInitialLocalLocationY/a-0.5})
W=12; U=[];T=[];V=[]
for (u,r),g in ev.sort_values('t').groupby(['user','round'],sort=False):
    rec=g.to_dict('records')
    for k in range(len(rec)//W): U.append(u);T.append(rec[k*W]['t']);V.append(window_vector(rec[k*W:(k+1)*W],'tap'))
U=np.array(U);T=np.array(T);V=np.vstack(V); sit=np.zeros(len(U),int)
for u in np.unique(U):
    idx=np.where(U==u)[0];o=idx[np.argsort(T[idx])];k=0
    for j,i in enumerate(o):
        if j and T[i]-T[o[j-1]]>1800:k+=1
        sit[i]=k
users=[u for u in np.unique(U) if sit[U==u].max()>=2 and (U==u).sum()>=15]
early=np.zeros(len(U),bool)
for u in np.unique(U):
    idx=np.where(U==u)[0]; ns=sit[idx].max()+1; early[idx]=sit[idx]<max(1,round(0.6*ns))
def eer(y,s):
    f,t_,_=roc_curve(y,s);fn=1-t_;i=np.nanargmin(np.abs(fn-f));return (f[i]+fn[i])/2
res={}
for seed in (1,2,3):
  rng=np.random.default_rng(seed)
  for u in users:
    others=np.array([o for o in users if o!=u]); rng.shuffle(others); h=len(others)//2
    bg=set(others[:h]); te_imp=set(others[h:])
    gtr=np.where((U==u)&early)[0]; gte=np.where((U==u)&~early)[0]
    btr=np.where(np.isin(U,list(bg))&early)[0]; ite=np.where(np.isin(U,list(te_imp))&~early)[0]
    if len(gtr)<8 or len(gte)<5: continue
    mu=V[gtr].mean(0); sd=V[np.r_[gtr,btr]].std(0)+1e-6
    Z=lambda i:(V[i]-mu)/sd
    X=np.vstack([Z(gtr),Z(btr)]); y=np.r_[np.ones(len(gtr)),np.zeros(len(btr))]
    for name,clf in (('logreg',LogisticRegression(C=1.0,class_weight='balanced',max_iter=500)),('rf',RandomForestClassifier(150,min_samples_leaf=2,class_weight='balanced',n_jobs=2,random_state=seed))):
        clf.fit(X,y); sg=clf.predict_proba(Z(gte))[:,1]; si=clf.predict_proba(Z(ite))[:,1]
        res.setdefault((name,1),{}).setdefault(u,[]).append(eer(np.r_[np.ones(len(sg)),np.zeros(len(si))],np.r_[sg,si]))
        og=np.argsort(T[gte]); g5=[sg[og][j:j+5].mean() for j in range(0,len(sg)-4,5)]
        i5=[]
        for o in te_imp:
            m=U[ite]==o; v=si[m][np.argsort(T[ite][m])]; i5+=[v[j:j+5].mean() for j in range(0,len(v)-4,5)]
        if len(g5)>=2: res.setdefault((name,5),{}).setdefault(u,[]).append(eer(np.r_[np.ones(len(g5)),np.zeros(len(i5))],np.r_[g5,i5]))
    # cohort-normalised distance (SABA-style)
    dist=lambda i:np.sqrt((((V[i]-mu)/sd)**2).mean(1))
    cg=dist(gtr); cb=dist(btr); m_,s_=cb.mean(),cb.std()+1e-6
    sg=-(dist(gte)-m_)/s_; si=-(dist(ite)-m_)/s_
    res.setdefault(('cohortdist',1),{}).setdefault(u,[]).append(eer(np.r_[np.ones(len(sg)),np.zeros(len(si))],np.r_[sg,si]))
out={}
for k,d in res.items():
    v=np.array([np.mean(x) for x in d.values()]); out[f'{k[0]}_K{k[1]}']=(len(v),round(float(np.median(v)),4))
print(out)
