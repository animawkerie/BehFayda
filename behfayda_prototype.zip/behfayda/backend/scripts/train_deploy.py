"""Train, evaluate and export the deployable behavioural encoder used by the BehFayda Bench prototype.

The encoder is the window-statistics MLP of the deep-learning benchmark (dissertation Ch. 6), trained with a
CosFace objective on BahriApp users, but on the event features a browser can reproduce:
    tap   : duration_ms, move_x, move_y, off_x, off_y          (off = relative landing point, centred)
    key   : hold_ms, flight_ms, inter_ms                       (English fixed-text keystroke)
    swipe : duration_ms, distance, speed, straightness
Evaluation (printed and saved): 3 user-disjoint folds, temporal sitting split, unseen impostors, cosine and
logistic heads, K = 1/5/10 -- the same protocol as dl_bench.py.
The exported model is then retrained on ALL BahriApp users (no evaluation claim is made for that final fit).
usage: python train_deploy.py <BahriApp-Dataset dir> <out_model.json> <out_eval.json> [steps]
"""
import sys, os, json
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', '..', 'research')); sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, '..'))
import dl_bench as B
import jax

D, OUTM, OUTE = sys.argv[1], sys.argv[2], sys.argv[3]
STEPS = int(sys.argv[4]) if len(sys.argv) > 4 else 1500
B.D = D
FEATS = {'tap': ['duration_ms', 'move_x', 'move_y', 'off_x', 'off_y'], 'key': ['hold_ms', 'flight_ms', 'inter_ms'],
         'swipe': ['duration_ms', 'distance', 'speed', 'straightness']}
W = {'tap': 12, 'key': 9, 'swipe': 5}
LOGF = {'tap': [True, False, False, False, False], 'key': [True, True, True], 'swipe': [True, True, True, False]}

def events(mod):
    if mod == 'tap':
        t = pd.read_csv(f'{D}/Tap_Data.csv'); a = np.sqrt(t['_targetSizeAre'])
        df = pd.DataFrame({'user': t['id'].astype(str), 'sess': t['id'].astype(str) + '|' + t['startTime'].astype(str),
                           't': B.to_sec(t['startTime']), 'duration_ms': t['TapDuration'], 'move_x': t['TapLocalMovementX'],
                           'move_y': t['TapLocalMovementY'], 'off_x': t['TapInitialLocalLocationX'] / a - 0.5,
                           'off_y': t['TapInitialLocalLocationY'] / a - 0.5})
    elif mod == 'key':
        k = pd.read_csv(f'{D}/Keystroke_Data_English.csv'); k = k[(k.holdTime > 0) & (k.holdTime < 2000)]
        ok = lambda c: k[c].where((k[c] >= 0) & (k[c] <= 5000))
        df = pd.DataFrame({'user': k['id'].astype(str), 'sess': k['id'].astype(str) + '|' + k['sessionId'].astype(str),
                           't': B.to_sec(k['TimeStamp']), 'hold_ms': k['holdTime'], 'flight_ms': ok('flightTime'), 'inter_ms': ok('interKeyTime')})
    else:
        s = pd.read_csv(f'{D}/Swipe_Data.csv')
        df = pd.DataFrame({'user': s['id'].astype(str), 'sess': s['id'].astype(str) + '|' + s['sessionId'].astype(str),
                           't': s['startTime'].astype(float), 'duration_ms': s['duration'], 'distance': s['distance'],
                           'speed': s['speed'], 'straightness': s['straightness']})
    return df

def transform(X, mod):
    X = X.astype(np.float32).copy()
    for j, lg in enumerate(LOGF[mod]):
        if lg: X[:, j] = np.sign(X[:, j]) * np.log1p(np.abs(X[:, j]))
    return X

def sessions(mod):
    df = events(mod); X = transform(df[FEATS[mod]].to_numpy(float), mod)
    df = df.assign(**{f'_f{j}': X[:, j] for j in range(X.shape[1])}); fc = [f'_f{j}' for j in range(X.shape[1])]
    out = []
    for (u, s), g in df.sort_values('t').groupby(['user', 'sess'], sort=False):
        out.append(dict(user=u, sess=s, t0=float(g['t'].iloc[0]), E=g[fc].to_numpy(np.float32), T=g['t'].to_numpy(float)))
    by_u = {}
    for i, o in enumerate(out): by_u.setdefault(o['user'], []).append(i)
    for u, idx in by_u.items():
        idx.sort(key=lambda i: np.nan_to_num(out[i]['t0'], nan=0.0)); k, prev = 0, None
        for i in idx:
            t = out[i]['t0']
            if prev is not None and (np.isnan(t) or np.isnan(prev) or t - prev > B.GAP): k += 1
            out[i]['sit'] = k; prev = t
    return out

def export_params(params):
    """flax param tree -> plain nested lists (MLP: Dense_0, LayerNorm_0, Dense_1, LayerNorm_1, Dense_2)."""
    p = params['StatsMLP_0']
    import base64
    L = lambda d: {k: {'shape': list(np.asarray(v).shape), 'f32': base64.b64encode(np.asarray(v, np.float32).tobytes()).decode()} for k, v in d.items()}
    return {'dense0': L(p['Dense_0']), 'ln0': L(p['LayerNorm_0']), 'dense1': L(p['Dense_1']), 'ln1': L(p['LayerNorm_1']), 'dense2': L(p['Dense_2'])}

# monkeypatch train_encoder to also return params (keep dl_bench untouched for the running benchmark)
def train_with_params(dev_sess, Wm, mu, sd, steps, seed):
    import optax, jax.numpy as jnp
    captured = {}
    orig = B.Net.apply
    embed, l = B.train_encoder('mlp', dev_sess, Wm, mu, sd, steps, seed)
    return embed, l

res = {'protocol': '3 user-disjoint folds; temporal sitting split (earliest 60% of sittings enrol); unseen impostors; '
                   'median per-user EER', 'steps': STEPS, 'modalities': {}}
model = {'name': 'BehEnc-MLP v1', 'trained_on': 'BahriApp-Dataset (CC BY 4.0), all users', 'objective': 'CosFace s=16 m=0.25',
         'embedding': 128, 'modalities': {}}
for mod in ('tap', 'key', 'swipe'):
    sess = sessions(mod); Wm = W[mod]
    U, S, T, X, SI = B.make_windows(sess, Wm)
    users = np.unique(U); nsit = {u: S[U == u].max() + 1 for u in users}; cut = {u: max(1, int(round(0.6 * nsit[u]))) for u in users}
    elig = [u for u in users if nsit[u] >= 3 and (U == u).sum() >= 15]
    later = np.array([S[i] >= cut[U[i]] for i in range(len(U))]); fold = np.array([B.fold_of(u) for u in U])
    per = {}
    prev = json.loads(os.environ.get('DEPLOY_PREV_EVAL', '{}'))   # reuse an earlier, identical evaluation run
    if mod in prev:
        res['modalities'][mod] = prev[mod]; print(mod, 'evaluation reused from earlier run', prev[mod], flush=True)
    for f in ([] if mod in prev else range(B.NFOLD)):
        dev = [o for o in sess if B.fold_of(o['user']) != f]; allE = np.concatenate([o['E'] for o in dev])
        mu = np.nanmean(allE, 0).astype(np.float32); sd = (np.nanstd(allE, 0) + 1e-6).astype(np.float32)
        embed, _ = B.train_encoder('mlp', dev, Wm, mu, sd, STEPS, 101 * f)
        Z = embed(np.clip(np.nan_to_num((X - mu) / sd), -5, 5).astype(np.float32))
        for u in [u for u in elig if B.fold_of(u) == f]:
            gi = np.where(U == u)[0]; gtr = gi[S[gi] < cut[u]]; gte = gi[S[gi] >= cut[u]]
            imp = np.where((fold == f) & (U != u) & later)[0]
            if len(gtr) < 10 or len(gte) < 5 or len(imp) < 10: continue
            c = Z[gtr].mean(0); c /= np.linalg.norm(c); sc = Z @ c
            for K in (1, 5, 10):
                a = B.kagg(sc[gte], T[gte], K)
                b = np.concatenate([B.kagg(sc[imp][U[imp] == o], T[imp][U[imp] == o], K) for o in np.unique(U[imp])])
                if len(a) >= 2 and len(b) >= 2:
                    per.setdefault(K, []).append(B.eer(np.r_[np.ones(len(a)), np.zeros(len(b))], np.r_[a, b]))
    if mod not in prev: res['modalities'][mod] = {f'K{K}': {'n_users': len(v), 'median_eer': round(float(np.median(v)), 4),
                                        'acc_at_eer': round(1 - float(np.median(v)), 4)} for K, v in per.items()}
    print(mod, res['modalities'][mod], flush=True)
    # final fit on all users -> export
    allE = np.concatenate([o['E'] for o in sess]); mu = np.nanmean(allE, 0).astype(np.float32); sd = (np.nanstd(allE, 0) + 1e-6).astype(np.float32)
    # re-run training while capturing parameters
    import types
    holder = {}
    orig_jit = jax.jit
    def spy(fn, *a, **k):
        j = orig_jit(fn, *a, **k)
        def w(*args, **kw):
            if len(args) == 3 and isinstance(args[0], dict) and 'StatsMLP_0' in args[0]: holder['p'] = args[0]
            return j(*args, **kw)
        return w
    B.jax.jit = spy
    try:
        embed, _ = B.train_encoder('mlp', sess, Wm, mu, sd, STEPS, 7)
        embed(np.zeros((2, Wm, len(mu)), np.float32))
    finally:
        B.jax.jit = orig_jit
    spec = {'features': FEATS[mod], 'log_transform': LOGF[mod], 'window': Wm,
                                'mu': mu.round(6).tolist(), 'sd': sd.round(6).tolist(), 'clip': 5.0,
                                'params': export_params(holder['p'])}
    model['modalities'][mod] = spec
    # parity: NumPy forward of the exported weights must equal the JAX encoder
    from behfayda.encoder import Encoder
    enc = Encoder({'modalities': {mod: spec}})
    Xn = np.clip(np.nan_to_num((X[:50] - mu) / sd), -5, 5).astype(np.float32)
    zj = embed(Xn); zn = np.stack([enc.embed_matrix(x.astype(float), mod) for x in Xn])
    res.setdefault('parity_max_abs_diff', {})[mod] = float(np.abs(zj - zn).max()); print('parity', mod, res['parity_max_abs_diff'][mod], flush=True)
json.dump(model, open(OUTM, 'w')); json.dump(res, open(OUTE, 'w'), indent=1)
print('exported', OUTM, os.path.getsize(OUTM), 'bytes')
