"""Offline evaluation of the PROTOTYPE's one-class scorer on replayed BahriApp tap data.

Same protocol as the reconciled baseline (sitting split, earliest 60% enrol, unseen-user impostors),
but with the deployable one-class template (no impostor data at enrolment), so the number reported
is what the prototype itself would achieve. Also exports a replay bundle for the web demo.
usage: python -I replay_eval.py <Tap_Data.csv> <out_dir>
"""
import sys, os, json
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
import numpy as np, pandas as pd
from sklearn.metrics import roc_curve
from behfayda.core import window_vector, enrol, Params, confidence

src, out = sys.argv[1], sys.argv[2]; os.makedirs(out, exist_ok=True)
df = pd.read_csv(src)
df['t'] = (pd.to_datetime(df['startTime']) - pd.Timestamp('1970-01-01')).dt.total_seconds()
df['user'] = df['id'].astype(str)
df['round'] = df['user'] + '|' + df['startTime'].astype(str)
a = np.sqrt(df['_targetSizeAre'])
ev = pd.DataFrame({'user': df['user'], 'round': df['round'], 't': df['t'],
                   'duration_ms': df['TapDuration'], 'move_x': df['TapLocalMovementX'],
                   'move_y': df['TapLocalMovementY'], 'off_x': df['TapInitialLocalLocationX'] / a - 0.5,
                   'off_y': df['TapInitialLocalLocationY'] / a - 0.5})
W = 12
rows = []
for (u, r), g in ev.sort_values('t').groupby(['user', 'round'], sort=False):
    recs = g.to_dict('records')
    for k in range(len(recs) // W):
        blk = recs[k * W:(k + 1) * W]
        rows.append((u, r, blk[0]['t'], window_vector(blk, 'tap'), blk))
U = np.array([x[0] for x in rows]); T = np.array([x[2] for x in rows]); V = np.vstack([x[3] for x in rows])
# sittings (30-min gap on round start)
sit = np.zeros(len(U), int)
for u in np.unique(U):
    idx = np.where(U == u)[0]; o = idx[np.argsort(T[idx])]; k = 0
    for j, i in enumerate(o):
        if j and T[i] - T[o[j - 1]] > 1800: k += 1
        sit[i] = k
users = [u for u in np.unique(U) if sit[U == u].max() >= 2 and (U == u).sum() >= 15]
p = Params()
def eer(y, s):
    f, t_, _ = roc_curve(y, s); fn = 1 - t_; i = np.nanargmin(np.abs(fn - f)); return (f[i] + fn[i]) / 2
res = {1: [], 5: []}
rng = np.random.default_rng(1)
for u in users:
    idx = np.where(U == u)[0]; ns = sit[idx].max() + 1; cut = max(1, round(0.6 * ns))
    tr = idx[sit[idx] < cut]; te = idx[sit[idx] >= cut]
    if len(tr) < 8 or len(te) < 5: continue
    others = np.array([o for o in users if o != u]); rng.shuffle(others); h = len(others) // 2
    bg = others[:h]
    bgi = np.where(np.isin(U, bg))[0]
    bgi = np.array([i for i in bgi if sit[i] < max(1, round(0.6 * (sit[U == U[i]].max() + 1)))])
    tpl = enrol('tap', [V[i] for i in tr], p, background=[V[i] for i in bgi])
    imp = []
    for o in others[h:]:
        j = np.where(U == o)[0]; nso = sit[j].max() + 1
        imp.append(j[sit[j] >= max(1, round(0.6 * nso))])
    def conf_of(i):
        s, _ = tpl.score(V[i], p); return -(s - tpl.tau)
    g = np.array([conf_of(i) for i in te[np.argsort(T[te])]])
    for K in (1, 5):
        gk = g if K == 1 else np.array([g[j:j + K].mean() for j in range(0, len(g) - K + 1, K)])
        ik = []
        for j in imp:
            c = np.array([conf_of(i) for i in j[np.argsort(T[j])]])
            ik += list(c) if K == 1 else [c[m:m + K].mean() for m in range(0, len(c) - K + 1, K)]
        if len(gk) >= 2 and len(ik) >= 2:
            res[K].append(eer(np.r_[np.ones(len(gk)), np.zeros(len(ik))], np.r_[gk, ik]))
summary = {}
for K, v in res.items():
    v = np.array(v); b = [np.median(rng.choice(v, len(v))) for _ in range(2000)]
    summary[f'K{K}'] = dict(n_users=len(v), median_eer=round(float(np.median(v)), 4),
                            ci=[round(float(np.percentile(b, 2.5)), 4), round(float(np.percentile(b, 97.5)), 4)],
                            mean_eer=round(float(v.mean()), 4))
print(json.dumps(summary, indent=1))
json.dump(summary, open(f'{out}/prototype_replay_eval.json', 'w'), indent=1)

# replay bundle: the user with most windows (genuine) + one impostor, events only (CC BY 4.0 data)
cnt = pd.Series(U).value_counts()
gen = [u for u in cnt.index if u in users][0]
imp_u = [u for u in cnt.index if u in users and u != gen][1]
def events_of(u, part):
    idx = np.where(U == u)[0]; ns = sit[idx].max() + 1; cut = max(1, round(0.6 * ns))
    sel = idx[(sit[idx] < cut) if part == 'enrol' else (sit[idx] >= cut)]
    sel = sel[np.argsort(T[sel])]
    return [[{k: (None if pd.isna(e[k]) else round(float(e[k]), 4)) for k in ('duration_ms', 'move_x', 'move_y', 'off_x', 'off_y')}
             for e in rows[i][4]] for i in sel]
bundle = {'source': 'BahriApp-Dataset Tap_Data.csv (CC BY 4.0), replayed; participant ids pseudonymised',
          'genuine_label': 'Participant A', 'impostor_label': 'Participant B',
          'enrol': events_of(gen, 'enrol')[:40], 'genuine_stream': events_of(gen, 'test')[:30],
          'impostor_stream': events_of(imp_u, 'test')[:20]}
json.dump(bundle, open(f'{out}/replay_bundle.json', 'w'))
print('replay bundle windows', len(bundle['enrol']), len(bundle['genuine_stream']), len(bundle['impostor_stream']))
