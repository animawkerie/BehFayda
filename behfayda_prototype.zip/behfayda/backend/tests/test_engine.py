import os, sys, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
import numpy as np, pytest
from behfayda.core import (enrol, Params, Session, window_vector, saba_update, TRUSTED, STEP_UP, DENIED)
from behfayda.privacy import epsilon, PrivacyLedger, dp_sgd_logistic

ROOT = os.path.join(os.path.dirname(__file__), '..')
BG = json.load(open(os.path.join(ROOT, 'data', 'background.json')))['modalities']
RB = json.load(open(os.path.join(ROOT, 'data', 'replay_bundle.json')))


def tpl_tap():
    ws = [window_vector(w, 'tap') for w in RB['enrol']]
    return enrol('tap', ws, Params(), background=[np.asarray(v) for v in BG['tap']])


def test_published_epsilon_table():
    # P7 Table III: q=0.2, sigma=3, delta=1e-5 (RDP)
    for steps, eps in [(150, 4.046), (200, 4.735), (300, 5.936), (500, 7.956), (650, 9.279)]:
        assert abs(epsilon(steps) - eps) < 0.002


def test_ledger_allows_14_updates_then_refuses():
    L = PrivacyLedger()
    assert L.remaining_updates() == 14
    for _ in range(14): L.charge_update()
    assert L.eps <= 8.0
    with pytest.raises(PermissionError): L.charge_update()


def test_dp_sgd_runs_and_clips():
    rng = np.random.default_rng(0)
    units = [(rng.normal(size=(5, 4)), rng.integers(0, 2, 5).astype(float)) for _ in range(30)]
    w = dp_sgd_logistic(units, steps=20)
    assert w.shape == (5,) and np.all(np.isfinite(w))


def test_trust_region_is_never_left_under_adversarial_stream():
    """SABA Proposition 1: for ANY admitted sequence the profile stays within the region."""
    p = Params(); t = tpl_tap(); rng = np.random.default_rng(1)
    target = rng.normal(size=len(t.mu)) * 10
    for day in range(50):
        for _ in range(10):
            saba_update(t, target + rng.normal(size=len(t.mu)) * 0.01, p, day)
        assert np.linalg.norm(np.asarray(t.mu) - np.asarray(t.anchor)) <= p.region_radius + 1e-9


def test_daily_cap_limits_single_day_movement():
    p = Params(); t = tpl_tap(); rng = np.random.default_rng(2)
    start = np.asarray(t.mu).copy()
    for _ in range(100):
        saba_update(t, rng.normal(size=len(t.mu)) * 5, p, day_index=0)
    assert np.linalg.norm(np.asarray(t.mu) - start) <= p.daily_cap + 1e-6


def test_angular_screen_blocks_straight_line_poisoning():
    p = Params(); t = tpl_tap(); d = np.ones(len(t.mu)) / np.sqrt(len(t.mu))
    ok1, _ = saba_update(t, np.asarray(t.mu) + 3 * d, p, 0)
    ok2, why = saba_update(t, np.asarray(t.mu) + 3 * d, p, 0)
    assert ok1 and not ok2 and 'angular' in why


def test_genuine_replay_stays_trusted_more_than_impostor():
    s = Session('A', {'tap': tpl_tap()})
    gen = [s.observe('tap', w)['assurance'] for w in RB['genuine_stream'][:15]]
    s2 = Session('A', {'tap': tpl_tap()})
    imp = [s2.observe('tap', w)['assurance'] for w in RB['impostor_stream'][:15]]
    assert np.mean(gen) > np.mean(imp)


def test_takeover_triggers_step_up_and_failed_stepup_rolls_back():
    s = Session('A', {'tap': tpl_tap()})
    for w in RB['genuine_stream'][:10]: s.observe('tap', w)
    states = [s.observe('tap', w)['decision'] for w in RB['impostor_stream'][:20]]
    assert STEP_UP in states
    r = s.step_up(False)
    assert 'rolled_back_to' in r
    r2 = s.step_up(False)
    assert r2['decision'] == DENIED


def test_evidence_gate_abstains_on_sparse_window():
    s = Session('A', {'tap': tpl_tap()})
    out = s.observe('tap', RB['genuine_stream'][0][:3])
    assert out['decision'] == 'INSUFFICIENT_EVIDENCE'


def test_access_and_update_are_separate():
    s = Session('A', {'tap': tpl_tap()})
    outs = [s.observe('tap', w) for w in RB['genuine_stream'][:12]]
    # some accepted windows must NOT be admitted to the profile (gate tau_g < tau)
    acc = [o for o in outs if o['decision'] == TRUSTED]
    assert any(not o['update'].startswith('silent, updated') for o in acc) or len(acc) == 0
