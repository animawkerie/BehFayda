import os, sys, json, tempfile
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
os.environ['BEHFAYDA_DB'] = os.path.join(tempfile.mkdtemp(), 'test.sqlite')
os.environ['BEHFAYDA_SECRET'] = 'test-secret'
from fastapi.testclient import TestClient
from behfayda.app import app

RB = json.load(open(os.path.join(os.path.dirname(__file__), '..', 'data', 'replay_bundle.json')))
c = TestClient(app)


def login(pid='demo-001', pin='1234'):
    return c.post('/mock-idp/login', json={'demo_id': pid, 'pin': pin}).json()['id_token']


def H(t): return {'Authorization': f'Bearer {t}'}


def test_full_flow():
    t = login()
    assert c.post('/v1/enrol/windows', headers=H(t), json={'modality': 'tap', 'events': RB['enrol'][0]}).status_code == 403
    c.post('/v1/consent', headers=H(t), json={'modalities': {'tap': True, 'key': False}})
    for w in RB['enrol'][:30]:
        assert c.post('/v1/enrol/windows', headers=H(t), json={'modality': 'tap', 'events': w}).json()['accepted']
    r = c.post('/v1/enrol/finalize?mode=stats', headers=H(t)).json()
    assert r['enrolled']['tap']['mode'].startswith('background')
    sid = c.post('/v1/sessions', headers=H(t)).json()['session_id']
    for w in RB['genuine_stream'][:8]:
        out = c.post(f'/v1/sessions/{sid}/windows', json={'modality': 'tap', 'events': w}).json()
        assert 'decision' in out and out['latency_ms'] < 50
    rp = c.get(f'/v1/rp/assurance/{sid}').json()
    assert set(rp) >= {'assurance_state', 'confidence', 'window_coverage'} and 'score' not in rp
    # step-up with a fresh token from the same identity succeeds; another identity fails
    assert c.post(f'/v1/sessions/{sid}/stepup', json={'id_token': login()}).json()['success']
    assert not c.post(f'/v1/sessions/{sid}/stepup', json={'id_token': login('someone-else')}).json()['success']
    pv = c.get(f'/v1/privacy/{sid}').json(); assert pv['remaining_dp_updates'] == 14
    assert c.get('/v1/audit/verify').json()['intact']
    assert c.delete('/v1/users/me', headers=H(t)).json()['erased']
    assert c.post('/v1/sessions', headers=H(t)).status_code == 404


def test_bad_token_rejected():
    assert c.post('/v1/sessions', headers={'Authorization': 'Bearer x.y.z'}).status_code == 401


def test_deep_enrolment_logout_and_benchmark_endpoints():
    from behfayda.app import ENCODER
    t = login('demo-deep', '9876')
    c.post('/v1/consent', headers=H(t), json={'modalities': {'tap': True}})
    for w in RB['enrol'][:20]:
        c.post('/v1/enrol/windows', headers=H(t), json={'modality': 'tap', 'events': w})
    r = c.post('/v1/enrol/finalize', headers=H(t)).json()
    if ENCODER is not None:
        assert r['enrolled']['tap']['mode'].startswith('deep')
    sid = c.post('/v1/sessions', headers=H(t)).json()['session_id']
    out = [c.post(f'/v1/sessions/{sid}/windows', json={'modality': 'tap', 'events': w}).json() for w in RB['impostor_stream'][:10]]
    assert all('risk' in o for o in out if o.get('decision') != 'INSUFFICIENT_EVIDENCE')
    assert c.post(f'/v1/sessions/{sid}/logout', json={'reason': 'takeover'}).json()['logged_out']
    assert c.post(f'/v1/sessions/{sid}/windows', json={'modality': 'tap', 'events': RB['genuine_stream'][0]}).status_code == 404
    acts = [a['action'] for a in c.get('/v1/audit?limit=200').json()]
    assert 'forced_logout' in acts
    # benchmark: two participants, labelled windows, stored without content
    for p, stream in (('P01', RB['enrol']), ('P02', RB['impostor_stream'])):
        for k, w in enumerate(stream[:10]):
            ok = c.post('/v1/bench/samples', json={'participant': p, 'modality': 'tap', 'phase': 'enrol' if k < 6 else 'test', 'events': w}).json()
            assert ok['accepted']
    ex = c.get('/v1/bench/samples').json(); assert ex['participants'] == ['P01', 'P02'] and ex['n'] == 20
    res = c.post('/v1/bench/run?modalities=tap').json()['tap']
    assert res['summary']['stats']['K1']['n'] == 2
    assert c.delete('/v1/bench/samples').json()['erased'] and c.get('/v1/bench/samples').json()['n'] == 0
