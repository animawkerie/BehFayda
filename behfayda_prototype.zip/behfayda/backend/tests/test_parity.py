"""The browser engine (frontend/core.js) must reproduce the Python engine on replayed BahriApp data."""
import os, sys, json, subprocess, shutil
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
import numpy as np, pytest
from behfayda.core import Session, enrol, window_vector, Params

ROOT = os.path.join(os.path.dirname(__file__), '..')
FRONT = os.path.join(ROOT, '..', 'frontend')
JS = r"""
const C = require(process.argv[2]); const fs = require('fs');
const bg = JSON.parse(fs.readFileSync(process.argv[3])).modalities.tap;
const rb = JSON.parse(fs.readFileSync(process.argv[4]));
const t = C.enrol('tap', rb.enrol.map(w => C.windowVector(w, 'tap')), bg);
const s = new C.Session('A', { tap: t });
const out = rb.genuine_stream.slice(0, 10).concat(rb.impostor_stream.slice(0, 10)).map(w => s.observe('tap', w));
console.log(JSON.stringify({ tau: t.tau, g_med: t.g_med, out: out.map(o => [o.score, o.assurance, o.decision]) }));
"""


@pytest.mark.skipif(shutil.which('node') is None, reason='node not installed')
def test_js_python_parity(tmp_path):
    f = tmp_path / 'p.js'; f.write_text(JS)
    bgp = os.path.join(ROOT, 'data', 'background.json'); rbp = os.path.join(ROOT, 'data', 'replay_bundle.json')
    js = json.loads(subprocess.check_output(['node', str(f), os.path.abspath(os.path.join(FRONT, 'core.js')), bgp, rbp]))
    bg = [np.asarray(v) for v in json.load(open(bgp))['modalities']['tap']]; rb = json.load(open(rbp))
    t = enrol('tap', [window_vector(w, 'tap') for w in rb['enrol']], Params(), background=bg)
    s = Session('A', {'tap': t})
    py = [s.observe('tap', w) for w in rb['genuine_stream'][:10] + rb['impostor_stream'][:10]]
    assert abs(js['tau'] - t.tau) < 1e-6 and abs(js['g_med'] - t.g_med) < 1e-6
    for (sj, aj, dj), o in zip(js['out'], py):
        assert abs(sj - o['score']) < 2e-3 and abs(aj - o['assurance']) < 2e-3 and dj == o['decision']
