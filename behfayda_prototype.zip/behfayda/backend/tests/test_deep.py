"""Tests for the v2 additions: BehEnc encoder, deep templates, session risk, enforced logout, benchmark tool."""
import os, sys, json, subprocess, shutil
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
import numpy as np, pytest
from behfayda.core import Session, enrol_deep, Params, session_risk
from behfayda.encoder import Encoder
from behfayda import bench

ROOT = os.path.join(os.path.dirname(__file__), '..')
MODEL = os.path.join(ROOT, '..', 'models', 'behenc_mlp_v1.json')
FRONT = os.path.join(ROOT, '..', 'frontend')
RB = json.load(open(os.path.join(ROOT, 'data', 'replay_bundle.json')))
need_model = pytest.mark.skipif(not os.path.exists(MODEL), reason='encoder not exported')


@need_model
def test_encoder_unit_norm_and_deterministic():
    enc = Encoder(MODEL)
    e1 = enc.embedding(RB['enrol'][0], 'tap'); e2 = enc.embedding(RB['enrol'][0], 'tap')
    assert e1.shape == (128,) and abs(np.linalg.norm(e1) - 1) < 1e-4 and np.allclose(e1, e2)
    assert set(enc.m['modalities']) == {'tap', 'key', 'swipe'}


@need_model
def test_deep_session_separates_genuine_and_impostor_and_flags_takeover():
    enc = Encoder(MODEL)
    t = enrol_deep('tap', [enc.embedding(w, 'tap') for w in RB['enrol']], Params())
    assert t.kind == 'deep' and t.radius > 0 and t.cap > 0
    s = Session('A', {'tap': t}, featurize=lambda m, ev: enc.embedding(ev, m))
    gen = [s.observe('tap', w) for w in RB['genuine_stream'][:12]]
    s2 = Session('A', {'tap': t}, featurize=lambda m, ev: enc.embedding(ev, m))
    imp = [s2.observe('tap', w) for w in RB['impostor_stream'][:12]]
    assert np.mean([o['score'] for o in gen]) < np.mean([o['score'] for o in imp])
    assert all(0.0 <= o['risk'] <= 1.0 for o in gen + imp)
    assert any(o['takeover'] for o in imp), 'impostor stream should reach the CUSUM bound'


def test_session_risk_definition():
    assert session_risk(None, 0.0, 5.0) == 0.0
    assert abs(session_risk(0.9, 0.0, 5.0) - 0.1) < 1e-12
    assert session_risk(0.9, 5.0, 5.0) == 1.0
    assert session_risk(1.0, 2.5, 5.0) == 0.5


@need_model
def test_benchmark_protocol_on_synthetic_participants():
    """Two well-separated synthetic participants must give low EER; templates never see test windows."""
    rng = np.random.default_rng(0); enc = Encoder(MODEL); S = []
    for p, (dur, off) in {'P01': (70, -0.2), 'P02': (160, 0.25)}.items():
        for k in range(12):
            ev = [{'duration_ms': float(rng.normal(dur, 8)), 'move_x': float(rng.normal(0, 1)), 'move_y': float(rng.normal(0, 1)),
                   'off_x': float(rng.normal(off, .05)), 'off_y': float(rng.normal(off, .05))} for _ in range(12)]
            S.append({'participant': p, 'modality': 'tap', 'phase': 'enrol' if k < 6 else 'test', 'ts': k, 'events': ev})
    r = bench.run(S, 'tap', enc)
    assert r['summary']['deep']['K1']['n'] == 2 and r['summary']['stats']['K1']['n'] == 2
    assert r['summary']['deep']['K1']['median_eer'] <= 0.2
    for o in r['participants']:
        assert o['n_enrol'] == 6 and o['n_genuine'] == 6


@need_model
@pytest.mark.skipif(shutil.which('node') is None, reason='node not installed')
def test_js_python_parity_deep(tmp_path):
    js = r"""
const C = require(process.argv[2]), E = require(process.argv[3]); const fs = require('fs');
const M = JSON.parse(fs.readFileSync(process.argv[4])); const rb = JSON.parse(fs.readFileSync(process.argv[5]));
const emb = rb.enrol.map(w => E.embedding(M, 'tap', w, null)); const t = C.enrolDeep('tap', emb, null);
const s = new C.Session('A', { tap: t }, (m, ev) => E.embedding(M, m, ev, null));
const out = rb.genuine_stream.slice(0, 8).concat(rb.impostor_stream.slice(0, 8)).map(w => s.observe('tap', w));
console.log(JSON.stringify({ e0: emb[0], tau: t.tau, out: out.map(o => [o.score, o.assurance, o.risk, o.decision, o.takeover]) }));
"""
    f = tmp_path / 'p.js'; f.write_text(js)
    o = json.loads(subprocess.check_output(['node', str(f), os.path.abspath(os.path.join(FRONT, 'core.js')),
                                            os.path.abspath(os.path.join(FRONT, 'encoder.js')), MODEL, os.path.join(ROOT, 'data', 'replay_bundle.json')]))
    enc = Encoder(MODEL)
    assert np.allclose(o['e0'], enc.embedding(RB['enrol'][0], 'tap'), atol=1e-5)
    t = enrol_deep('tap', [enc.embedding(w, 'tap') for w in RB['enrol']], Params())
    assert abs(o['tau'] - t.tau) < 1e-4
    s = Session('A', {'tap': t}, featurize=lambda m, ev: enc.embedding(ev, m))
    py = [s.observe('tap', w) for w in RB['genuine_stream'][:8] + RB['impostor_stream'][:8]]
    for (sj, aj, rj, dj, kj), p in zip(o['out'], py):
        assert abs(sj - p['score']) < 2e-3 and abs(aj - p['assurance']) < 2e-3 and abs(rj - p['risk']) < 2e-3
        assert dj == p['decision'] and kj == p['takeover']
