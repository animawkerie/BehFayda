"""End-to-end functional test of BehFayda Bench v2 in a phone-sized headless Chrome.
Drives: two participants collect -> train (deep encoder) -> protected bank use -> takeover by a different synthetic
person -> voice alarm + enforced logout -> re-login -> benchmark run -> live takeover trial -> replay.
Synthetic pointer input is NOT behavioural evidence: this tests function, not accuracy."""
import asyncio, json, os, random
from playwright.async_api import async_playwright

H = os.path.dirname(os.path.abspath(__file__)); OUT = os.path.join(H, 'screens'); os.makedirs(OUT, exist_ok=True)
URL = 'file://' + os.path.join(H, 'frontend', 'index.html')
CHROME = os.environ.get('CHROME', '/usr/bin/google-chrome')
rnd = random.Random(7)
report = {}
# synthetic "persons": tap hold (ms), landing offset (px), key hold (ms), key gap (ms), swipe speed factor
PERSON = {0: dict(hold=(70, 105), off=(0, 0), kh=(80, 115), gap=(120, 220), sw=12), 1: dict(hold=(210, 300), off=(22, -16), kh=(170, 240), gap=(380, 520), sw=40),
          2: dict(hold=(130, 170), off=(-14, 12), kh=(120, 150), gap=(250, 330), sw=25)}


async def tap_el(page, el, person=0, jitter=6):
    try: await el.evaluate("e=>e.scrollIntoView({block:'center'})")
    except Exception: return
    b = await el.bounding_box()
    if b is None: return
    P = PERSON[person]; cx, cy = b['x'] + b['width'] / 2 + P['off'][0], b['y'] + b['height'] / 2 + P['off'][1]
    await page.mouse.move(cx + rnd.uniform(-jitter, jitter), cy + rnd.uniform(-jitter, jitter))
    await page.mouse.down(); await page.wait_for_timeout(rnd.uniform(*P['hold']))
    await page.mouse.move(cx + rnd.uniform(-1, 1) + person * 4, cy + rnd.uniform(-1, 1)); await page.mouse.up()


async def key_el(page, el, person=0):
    P = PERSON[person]; b = await el.bounding_box()
    if b is None: return
    await page.mouse.move(b['x'] + b['width'] / 2, b['y'] + b['height'] / 2); await page.mouse.down()
    await page.wait_for_timeout(rnd.uniform(*P['kh'])); await page.mouse.up(); await page.wait_for_timeout(rnd.uniform(*P['gap']))


async def swipe(page, sel, person=0):
    el = await page.query_selector(sel); await el.scroll_into_view_if_needed(); b = await el.bounding_box()
    y = b['y'] + b['height'] / 2 + rnd.uniform(-10, 10); x0 = b['x'] + b['width'] * 0.3; x1 = b['x'] + b['width'] * (0.85 if rnd.random() > .5 else 0.05)
    await page.mouse.move(x0, y); await page.mouse.down()
    for k in range(8):
        await page.mouse.move(x0 + (x1 - x0) * (k + 1) / 8, y + (k % 2) * (2 + person * 5)); await page.wait_for_timeout(PERSON[person]['sw'])
    await page.mouse.up(); await page.wait_for_timeout(250)


async def sign_in(page, pid, pin):
    await page.fill('#demoId', pid); await page.fill('#demoPin', pin); await page.click('#btnLogin'); await page.wait_for_timeout(250)


async def collect_and_train(page, person, shots=False):
    await page.click('#btnConsent'); await page.wait_for_timeout(300)
    for _ in range(12 * 6): await tap_el(page, await page.query_selector('#tapArena .tgt'), person); await page.wait_for_timeout(80)
    keys = await page.query_selector_all('#kb .k')
    await keys[0].evaluate("e=>e.scrollIntoView({block:'center'})")
    for _ in range(9 * 6 + 2): await key_el(page, (await page.query_selector_all('#kb .k'))[rnd.randrange(0, 26)], person)
    for _ in range(5 * 5): await swipe(page, '#swipeArena', person)
    if shots:
        await page.evaluate("document.getElementById('kbAm').click()"); await page.wait_for_timeout(200)
        await page.evaluate("document.getElementById('phrase').scrollIntoView({block:'start'}); window.scrollBy(0,-130)"); await page.wait_for_timeout(200)
        await page.screenshot(path=f'{OUT}/03_collect.png')
    counts = await page.evaluate("['e-tap','e-key','e-swipe'].map(i=>document.getElementById(i).textContent)")
    await page.click('#btnToTrain'); await page.wait_for_timeout(300); await page.click('#btnTrain')
    await page.wait_for_selector('#btnStart:not(.hidden)', timeout=20000)
    if shots: await page.evaluate("window.scrollTo(0,0)"); await page.screenshot(path=f'{OUT}/04_train.png')
    rep = await page.evaluate("document.getElementById('trainReport').innerText")
    await page.click('#btnStart'); await page.wait_for_timeout(300)
    return counts, rep


async def bank_use(page, person, n, pin=None):
    """returns ('stepup'|'logout'|None, taps used)"""
    for i in range(n):
        if await page.is_visible('#lockModal'): return 'logout', i
        if await page.is_visible('#modal'):
            if pin is None: return 'stepup', i
            await page.fill('#mPin', pin); await page.click('#mOk'); await page.wait_for_timeout(250); report.setdefault('_stepups', 0); report['_stepups'] += 1; continue
        els = await page.query_selector_all('#s-bank [data-tap], #bens .ben')
        await tap_el(page, els[rnd.randrange(len(els))], person); await page.wait_for_timeout(70)
    if await page.is_visible('#lockModal'): return 'logout', n
    return None, n


async def main():
    async with async_playwright() as p:
        kw = {'executable_path': CHROME} if os.path.exists(CHROME) else {}
        br = await p.chromium.launch(args=['--no-sandbox', '--autoplay-policy=no-user-gesture-required'], **kw)
        ctx = await br.new_context(viewport={'width': 390, 'height': 844}, device_scale_factor=2)
        page = await ctx.new_page(); errs = []
        page.on('pageerror', lambda e: errs.append(str(e)))
        await page.goto(URL); await page.wait_for_timeout(300)
        report['model'] = await page.evaluate("window.MODEL ? window.MODEL.name : null")
        await page.screenshot(path=f'{OUT}/01_login.png')
        # ---- participant P02 first (so that P01 later trains with a same-domain cohort)
        await sign_in(page, 'P02', '1357'); c2, _ = await collect_and_train(page, 2)
        r, _ = await bank_use(page, 2, 12 * 4, pin='1357'); report['P02_collect'] = c2
        await page.evaluate("document.querySelector('nav button[data-go=bench]').click()"); await page.click('#btnNewPart'); await page.wait_for_timeout(200)
        # ---- owner P01
        await sign_in(page, 'P01', '2468'); await page.screenshot(path=f'{OUT}/02_consent.png')
        c1, rep = await collect_and_train(page, 0, shots=True); report['P01_collect'] = c1; report['P01_train_report'] = rep
        report['_stepups'] = 0
        res, used = await bank_use(page, 0, 12 * 8, pin='2468')
        report['owner_phase'] = {'taps': used, 'genuine_stepups': report.pop('_stepups'), 'ended_by': res}
        await page.evaluate("window.scrollTo(0,0)"); await page.screenshot(path=f'{OUT}/05_bank_trusted.png')
        report['bar_after_owner'] = await page.evaluate("({s: document.getElementById('ast').textContent, a: document.getElementById('aval').textContent})")
        await page.evaluate("document.querySelector('nav button[data-go=monitor]').click()"); await page.wait_for_timeout(300)
        await page.screenshot(path=f'{OUT}/06_monitor.png')
        st = await page.add_style_tag(content='header,#abar,nav{position:static!important}')
        await page.screenshot(path=f'{OUT}/06b_monitor_full.png', full_page=True)
        await st.evaluate('e=>e.remove()')
        report['kpis_owner'] = await page.evaluate("document.getElementById('kpis').innerText")
        await page.evaluate("document.querySelector('nav button[data-go=bank]').click()"); await page.wait_for_timeout(200)
        # ---- takeover by a different person: expect alarm + enforced logout
        alarms0 = await page.evaluate("__state.alarms")
        res, used = await bank_use(page, 1, 12 * 12, pin=None)
        if res == 'stepup':   # a step-up may come first; the impostor cannot pass it -> continue using -> logout
            await page.fill('#mPin', '0000'); await page.click('#mOk'); await page.wait_for_timeout(300)
            res2, used2 = await bank_use(page, 1, 12 * 10, pin=None); used += used2
            if res2 == 'stepup': await page.fill('#mPin', '1111'); await page.click('#mOk'); await page.wait_for_timeout(300); res2 = 'logout' if await page.is_visible('#lockModal') else res2
            res = res2
        report['takeover'] = {'ended_by': res, 'impostor_taps': used, 'alarms': (await page.evaluate("__state.alarms")) - alarms0,
                              'lock_text': await page.evaluate("document.getElementById('lockText').textContent")}
        await page.screenshot(path=f'{OUT}/07_locked.png')
        if await page.is_visible('#lockModal'): await page.click('#lockOk'); await page.wait_for_timeout(200)
        await page.screenshot(path=f'{OUT}/08_relogin.png')
        # ---- re-login opens a new protected session with the trained profile
        await sign_in(page, 'P01', '2468'); report['relogin_session'] = await page.evaluate("!!__state.sess")
        await bank_use(page, 0, 12 * 3, pin='2468')
        # ---- live takeover trial
        await page.evaluate("document.querySelector('nav button[data-go=bench]').click()"); await page.click('#btnTrial'); await page.wait_for_timeout(200)
        await bank_use(page, 0, 12 * 4, pin='2468')
        await page.evaluate("document.querySelector('nav button[data-go=bench]').click()"); await page.click('#btnHand'); await page.wait_for_timeout(200)
        res, used = await bank_use(page, 1, 12 * 14, pin=None)
        if res == 'stepup': await page.click('#mCancel'); res, u2 = await bank_use(page, 1, 12 * 10, pin=None)
        if await page.is_visible('#lockModal'): await page.click('#lockOk')
        report['trials'] = await page.evaluate("__state.trials")
        # ---- benchmark on the collected windows
        if await page.is_visible('#s-login'): await sign_in(page, 'P01', '2468')
        await page.evaluate("document.querySelector('nav button[data-go=bench]').click()"); await page.wait_for_timeout(200)
        await page.click('#btnBench'); await page.wait_for_timeout(1500)
        report['benchmark'] = await page.evaluate("(__state.lastBench||[]).map(r=>({mod:r.mod, v:r.verifier, n:r.n, K1:r.K1, K3:r.K3, K5:r.K5}))")
        await page.evaluate("document.getElementById('benchOut').scrollIntoView({block:'start'}); window.scrollBy(0,-330)"); await page.wait_for_timeout(200)
        await page.screenshot(path=f'{OUT}/09_bench.png')
        await page.click('#btnReplay'); await page.wait_for_timeout(6000)
        report['replay'] = await page.evaluate("document.getElementById('rkpis').innerText")
        await page.evaluate("document.getElementById('btnReplay').scrollIntoView({block:'start'}); window.scrollBy(0,-150)"); await page.wait_for_timeout(200)
        await page.screenshot(path=f'{OUT}/10_replay.png')
        await page.evaluate("document.querySelector('nav button[data-go=about]').click()"); await page.wait_for_timeout(200)
        await page.screenshot(path=f'{OUT}/11_about.png')
        report['page_errors'] = errs
        await br.close()
    print(json.dumps(report, indent=1, ensure_ascii=False))
    os.makedirs(os.path.join(H, 'results'), exist_ok=True)
    json.dump(report, open(os.path.join(H, 'results', 'e2e_report.json'), 'w'), indent=1, ensure_ascii=False)

asyncio.run(main())
