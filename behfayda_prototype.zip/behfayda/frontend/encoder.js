/* BehEnc-MLP forward pass in JavaScript (port of backend/behfayda/encoder.py; parity-tested).
   window of events -> signed log -> standardise -> clip -> window statistics -> MLP -> unit-norm 128-d. */
(function (root) {
  'use strict';
  // weights: nested arrays, or {shape, f32: base64 float32 little-endian} (decoded once, cached)
  function arr(v) { if (!v || !v.f32) return v; if (v._d) return v._d;
    const bin = typeof atob === 'function' ? atob(v.f32) : Buffer.from(v.f32, 'base64').toString('binary');
    const u8 = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
    const f = new Float32Array(u8.buffer); let out;
    if (v.shape.length === 2) { out = []; for (let r = 0; r < v.shape[0]; r++) out.push(f.subarray(r * v.shape[1], (r + 1) * v.shape[1])); } else out = f;
    Object.defineProperty(v, '_d', { value: out, enumerable: false }); return out; }
  const gelu = (x) => 0.5 * x * (1 + Math.tanh(Math.sqrt(2 / Math.PI) * (x + 0.044715 * x * x * x)));
  function dense(x, p) { const K = arr(p.kernel), b = arr(p.bias), out = Array.from(b);
    for (let i = 0; i < x.length; i++) { const xi = x[i]; if (xi === 0) continue; const row = K[i]; for (let j = 0; j < out.length; j++) out[j] += xi * row[j]; }
    return out; }
  function ln(x, p) { const n = x.length; let m = 0; for (const v of x) m += v; m /= n; let s = 0; for (const v of x) s += (v - m) * (v - m); s /= n;
    const d = Math.sqrt(s + 1e-6); const sc = arr(p.scale), bi = arr(p.bias); return x.map((v, j) => (v - m) / d * sc[j] + bi[j]); }
  function pct(col, q) { const s = col.slice().sort((a, b) => a - b); const h = (s.length - 1) * q, lo = Math.floor(h), hi = Math.ceil(h); return s[lo] + (s[hi] - s[lo]) * (h - lo); }
  function features(spec, events) { return events.map((e) => spec.features.map((c, j) => { let v = e[c]; if (v == null || !isFinite(v)) return NaN;
    return spec.log_transform[j] ? Math.sign(v) * Math.log1p(Math.abs(v)) : v; })); }
  function normalise(spec, X, local) { const mu = local ? local.mu : spec.mu, sd = local ? local.sd : spec.sd;
    return X.map((r) => r.map((v, j) => { let z = (v - mu[j]) / sd[j]; if (!isFinite(z)) z = 0; return Math.max(-spec.clip, Math.min(spec.clip, z)); })); }
  function stats(Xn) { const F = Xn[0].length, cols = [...Array(F).keys()].map((j) => Xn.map((r) => r[j]));
    const mean = cols.map((c) => c.reduce((a, b) => a + b, 0) / c.length);
    const std = cols.map((c, j) => Math.sqrt(c.reduce((a, b) => a + (b - mean[j]) ** 2, 0) / c.length));
    return mean.concat(std, cols.map((c) => pct(c, 0.25)), cols.map((c) => pct(c, 0.5)), cols.map((c) => pct(c, 0.75))); }
  function embedMatrix(spec, Xn) { const p = spec.params; let h = stats(Xn);
    h = ln(dense(h, p.dense0), p.ln0).map(gelu); h = ln(dense(h, p.dense1), p.ln1).map(gelu);
    const e = dense(h, p.dense2); const n = Math.sqrt(e.reduce((a, b) => a + b * b, 0)) + 1e-6; return e.map((v) => v / n); }
  function localStats(spec, windows) { const X = [].concat(...windows.map((w) => features(spec, w))); const F = spec.features.length;
    const mu = [], sd = []; for (let j = 0; j < F; j++) { const v = X.map((r) => r[j]).filter((x) => isFinite(x));
      const m = v.length ? v.reduce((a, b) => a + b, 0) / v.length : 0; mu.push(m);
      sd.push(v.length ? Math.sqrt(v.reduce((a, b) => a + (b - m) ** 2, 0) / v.length) + 1e-6 : 1); }
    return { mu, sd }; }
  function embedding(model, modality, events, local) { const spec = model.modalities[modality]; return embedMatrix(spec, normalise(spec, features(spec, events), local)); }
  const api = { embedding, embedMatrix, features, normalise, stats, localStats };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.BehEnc = api;
})(typeof window !== 'undefined' ? window : globalThis);
