/* BehFayda assurance engine — JavaScript port of backend/behfayda/core.py (parity-tested).
   Works in the browser (window.BehCore) and in Node (module.exports). */
(function (root) {
  'use strict';
  const EVENT_FEATURES = { tap: ['duration_ms', 'move_x', 'move_y', 'off_x', 'off_y'],
    swipe: ['duration_ms', 'distance', 'speed', 'straightness'], key: ['hold_ms', 'flight_ms'] };
  const WINDOW_EVENTS = { tap: 12, swipe: 5, key: 9 };
  const MIN_EVENTS = { tap: 8, swipe: 4, key: 6 };
  const P = { tau_quantile: 0.9, gate_quantile: 0.5, kappa: 0.974, eta: 0.2, region_radius: 1.5,
    daily_cap: 0.5, K: 5, trust_level: 0.7, stepup_level: 0.45, high_risk_level: 0.8,
    cusum_margin: 1.2, imp_shift_sd: 2.0, clip_z: 6.0 };

  // ---------- small numeric helpers (match numpy semantics)
  const isNum = (x) => typeof x === 'number' && isFinite(x);
  const sorted = (a) => a.slice().sort((x, y) => x - y);
  function quantile(a, q) { const s = sorted(a); if (!s.length) return NaN; const h = (s.length - 1) * q,
      lo = Math.floor(h), hi = Math.ceil(h); return s[lo] + (s[hi] - s[lo]) * (h - lo); }
  const median = (a) => quantile(a, 0.5);
  const mean = (a) => a.reduce((s, x) => s + x, 0) / a.length;
  const std = (a) => { const m = mean(a); return Math.sqrt(mean(a.map((x) => (x - m) * (x - m)))); };
  const norm = (v) => Math.sqrt(v.reduce((s, x) => s + x * x, 0));
  const sub = (a, b) => a.map((x, i) => x - b[i]);
  const add = (a, b) => a.map((x, i) => x + b[i]);
  const scale = (a, k) => a.map((x) => x * k);
  const dot = (a, b) => a.reduce((s, x, i) => s + x * b[i], 0);
  const clip = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
  const clone = (o) => JSON.parse(JSON.stringify(o));

  function windowVector(events, modality) {
    const cols = EVENT_FEATURES[modality]; const m = [], s = [], d = [];
    for (const c of cols) {
      const v = events.map((e) => e[c]).filter(isNum);
      if (!v.length) { m.push(0); s.push(0); d.push(0); continue; }
      m.push(mean(v)); s.push(std(v)); d.push(median(v));
    }
    return m.concat(s, d);
  }

  function trainLogreg(X, y, l2 = 1e-2, iters = 400, lr = 0.5) {
    const n = X.length, d = X[0].length; let npos = 0; for (const t of y) npos += t;
    const wpos = 0.5 / Math.max(npos, 1), wneg = 0.5 / Math.max(n - npos, 1);
    const w = new Array(d + 1).fill(0);
    for (let it = 0; it < iters; it++) {
      const g = new Array(d + 1).fill(0);
      for (let i = 0; i < n; i++) {
        let zz = w[d]; for (let j = 0; j < d; j++) zz += X[i][j] * w[j];
        const p = 1 / (1 + Math.exp(-clip(zz, -30, 30)));
        const r = (y[i] ? wpos : wneg) * (p - y[i]);
        for (let j = 0; j < d; j++) g[j] += r * X[i][j]; g[d] += r;
      }
      for (let j = 0; j < d; j++) g[j] += l2 * w[j];
      for (let j = 0; j <= d; j++) w[j] -= lr * g[j];
    }
    return w;
  }

  function llr(s, shift) { const dd = shift == null ? P.imp_shift_sd : shift; return dd * s - 0.5 * dd * dd; }
  const confidence = (s, tau) => 1 / (1 + Math.exp(2 * (s - tau)));

  function eerThreshold(sg, sb) {
    const cand = Array.from(new Set(sg.concat(sb))).sort((a, b) => a - b);
    let best = 9, bt = median(sg);
    for (const t of cand) {
      const frr = sg.filter((x) => x > t).length / sg.length, far = sb.filter((x) => x <= t).length / sb.length;
      if (Math.abs(frr - far) < best) { best = Math.abs(frr - far); bt = t; }
    }
    return bt;
  }

  function enrol(modality, windows, background) {
    if (windows.length < 4) throw new Error('need at least 4 enrolment windows');
    const d = windows[0].length;
    if (background && background.length >= 20) {
      const all = windows.concat(background);
      const c = [...Array(d).keys()].map((j) => mean(windows.map((w) => w[j])));
      const sc = [...Array(d).keys()].map((j) => { const v = std(all.map((w) => w[j])); return v > 1e-6 ? v : 1; });
      const Z = (w) => w.map((x, j) => clip((x - c[j]) / sc[j], -P.clip_z, P.clip_z));
      const X = windows.map(Z).concat(background.map(Z));
      const y = windows.map(() => 1).concat(background.map(() => 0));
      const raw = new Array(X.length).fill(0);
      for (let f = 0; f < 3; f++) {
        const tr = [], ytr = []; X.forEach((x, i) => { if (i % 3 !== f) { tr.push(x); ytr.push(y[i]); } });
        const w = trainLogreg(tr, ytr);
        X.forEach((x, i) => { if (i % 3 === f) raw[i] = -(dot(x, w.slice(0, d)) + w[d]); });
      }
      const w = trainLogreg(X, y);
      const rg = raw.filter((_, i) => y[i] === 1), rb = raw.filter((_, i) => y[i] === 0);
      const gmed = median(rg), gmad = Math.max(median(rg.map((r) => Math.abs(r - gmed))) * 1.4826, 1e-3);
      const sg = rg.map((r) => (r - gmed) / gmad), sb = rb.map((r) => (r - gmed) / gmad);
      const tau = eerThreshold(sg, sb), tau_g = median(sg), shift = Math.max(median(sb), 1);
      let S = 0, smax = 0; for (const s of sg) { S = Math.max(0, S + llr(s, shift)); smax = Math.max(smax, S); }
      const anchor = [...Array(d).keys()].map((j) => mean(windows.map(Z).map((z) => z[j])));
      return { modality, center: c, scale: sc, anchor, mu: anchor.slice(), g_med: gmed, g_mad: gmad, tau, tau_g,
        cusum_bound: Math.max(P.cusum_margin * smax, 3), day_start_mu: anchor.slice(), day_index: 0,
        last_step: null, n_enrol: windows.length, weights: w, imp_shift: shift };
    }
    // one-class mode (no background cohort available for this modality)
    const c = [...Array(d).keys()].map((j) => median(windows.map((w) => w[j])));
    const sc = [...Array(d).keys()].map((j) => { const col = windows.map((w) => w[j]);
      const iq = (quantile(col, 0.75) - quantile(col, 0.25)) / 1.349, sd = std(col); return iq > 1e-6 ? iq : sd > 1e-6 ? sd : 1; });
    const Z = windows.map((w) => w.map((x, j) => clip((x - c[j]) / sc[j], -P.clip_z, P.clip_z)));
    const n = Z.length, tot = Z.reduce((a, z) => add(a, z), new Array(d).fill(0));
    const loo = Z.map((z) => { const o = scale(sub(tot, z), 1 / (n - 1)); const df = sub(z, o); return Math.sqrt(mean(df.map((x) => x * x))); });
    const gmed = median(loo), gmad = Math.max(median(loo.map((x) => Math.abs(x - gmed))) * 1.4826, 1e-3);
    const s = loo.map((x) => (x - gmed) / gmad);
    let S = 0, smax = 0; for (const si of s) { S = Math.max(0, S + llr(si)); smax = Math.max(smax, S); }
    const anchor = scale(tot, 1 / n);
    return { modality, center: c, scale: sc, anchor, mu: anchor.slice(), g_med: gmed, g_mad: gmad,
      tau: quantile(s, P.tau_quantile), tau_g: quantile(s, P.gate_quantile), cusum_bound: Math.max(P.cusum_margin * smax, 3),
      day_start_mu: anchor.slice(), day_index: 0, last_step: null, n_enrol: n, weights: null, imp_shift: null };
  }

  // deep mode: cosine template on BehEnc embeddings (mirrors core.py enrol_deep)
  function enrolDeep(modality, emb, cohort) {
    if (emb.length < 4) throw new Error('need at least 4 enrolment windows');
    const n = emb.length, d = emb[0].length, tot = emb.reduce((a, z) => add(a, z), new Array(d).fill(0));
    const cosd = (a, b) => 1 - dot(a, b) / (norm(a) * norm(b) + 1e-12);
    const loo = emb.map((e) => cosd(e, scale(sub(tot, e), 1 / (n - 1))));
    const gmed = median(loo), gmad = Math.max(median(loo.map((x) => Math.abs(x - gmed))) * 1.4826, 1e-3);
    const sg = loo.map((x) => (x - gmed) / gmad); const anchor = scale(tot, 1 / n);
    let tau, shift = null;
    if (cohort && cohort.length >= 8) { const sb = cohort.map((c) => (cosd(c, anchor) - gmed) / gmad); tau = eerThreshold(sg, sb); shift = Math.max(median(sb), 1); }
    else tau = quantile(sg, P.tau_quantile);
    let S = 0, smax = 0; for (const s of sg) { S = Math.max(0, S + llr(s, shift)); smax = Math.max(smax, S); }
    const spread = median(emb.map((e) => norm(sub(e, anchor))));
    return { modality, kind: 'deep', center: new Array(d).fill(0), scale: new Array(d).fill(1), anchor, mu: anchor.slice(), g_med: gmed, g_mad: gmad,
      tau, tau_g: quantile(sg, P.gate_quantile), cusum_bound: Math.max(P.cusum_margin * smax, 3), day_start_mu: anchor.slice(), day_index: 0,
      last_step: null, n_enrol: n, weights: null, imp_shift: shift, radius: 1.5 * spread, cap: 0.5 * spread, loo_scores: sg };
  }
  const sessionRisk = (A, cusum, bound) => { const c = bound > 0 ? Math.min(1, cusum / bound) : 1; return A == null ? c : 1 - A * (1 - c); };

  function zOf(t, v) { if (t.kind === 'deep') return v.slice(); return v.map((x, j) => clip((x - t.center[j]) / t.scale[j], -P.clip_z, P.clip_z)); }
  function rawOf(t, z) {
    if (t.kind === 'deep') return 1 - dot(z, t.mu) / (norm(z) * norm(t.mu) + 1e-12);
    if (!t.weights) { const df = sub(z, t.mu); return Math.sqrt(mean(df.map((x) => x * x))); }
    const x = sub(z, sub(t.mu, t.anchor)); const d = x.length;
    return -(dot(x, t.weights.slice(0, d)) + t.weights[d]);
  }
  function score(t, v) { const z = zOf(t, v); return { s: (rawOf(t, z) - t.g_med) / t.g_mad, z }; }

  function sabaUpdate(t, z, day) {
    const mu = t.mu, mu0 = t.anchor;
    if (day !== t.day_index) { t.day_index = day; t.day_start_mu = mu.slice(); }
    const R = t.radius == null ? P.region_radius : t.radius, CAP = t.cap == null ? P.daily_cap : t.cap;
    const step = scale(sub(z, mu), P.eta);
    if (t.last_step) {
      const cos = dot(step, t.last_step) / (norm(step) * norm(t.last_step) + 1e-12);
      if (cos > P.kappa) return [false, `angular screen: consecutive steps collinear (cos=${cos.toFixed(3)} > ${P.kappa})`];
    }
    let prop = add(mu, step); const ds = t.day_start_mu;
    const projBall = (pt, c, r) => { const dv = sub(pt, c), n = norm(dv); return n > r ? add(c, scale(dv, r / n)) : pt; };
    for (let i = 0; i < 8; i++) { prop = projBall(prop, mu0, R); prop = projBall(prop, ds, CAP); }
    prop = projBall(prop, mu0, R);
    const binding = [];
    if (norm(sub(prop, mu0)) >= R - 1e-6) binding.push('trust region');
    if (norm(sub(prop, ds)) >= CAP - 1e-6) binding.push('daily cap');
    t.last_step = sub(prop, mu); t.mu = prop;
    return [true, 'updated' + (binding.length ? ` (binding: ${binding.join(', ')})` : '')];
  }

  class Session {
    constructor(user, templates, featurize) { this.featurize = featurize || null; this.user = user; this.templates = templates; this.recent = []; this.pending = [];
      this.cusum = 0; this.state = 'INSUFFICIENT_EVIDENCE'; this.stepupFailures = 0; this.versions = []; this.log = [];
      this.snapshot('enrolment (anchor)'); }
    snapshot(reason) { this.versions.push({ version: this.versions.length + 1, reason, time: Date.now(), templates: clone(this.templates) }); }
    restore(v) { const s = this.versions.find((x) => x.version === v); this.templates = clone(s.templates); this.snapshot(`rollback to v${v}`); }
    assurance() { if (!this.recent.length) return null; const last = this.recent.slice(-P.K); return confidence(mean(last.map((r) => r.margin)), 0); }
    observe(modality, events, day = 0, highRisk = false) {
      const t0 = (typeof performance !== 'undefined' ? performance.now() : Date.now());
      const out = { modality, n_events: events.length };
      const t = this.templates[modality];
      if (!t) { out.decision = 'ignored'; out.reason = 'modality not enrolled'; return out; }
      if (events.length < MIN_EVENTS[modality]) { out.decision = 'INSUFFICIENT_EVIDENCE';
        out.reason = `evidence gate: ${events.length} < ${MIN_EVENTS[modality]} events`; this.log.push(out); return out; }
      const { s, z } = score(t, this.featurize ? this.featurize(modality, events) : windowVector(events, modality)); const conf = confidence(s, t.tau);
      this.recent.push({ modality, s, conf, z, margin: s - t.tau });
      this.cusum = Math.max(0, this.cusum + llr(s, t.imp_shift));
      const A = this.assurance(); const bound = Math.min(...Object.values(this.templates).map((x) => x.cusum_bound));
      let state;
      if (this.cusum >= bound) state = 'STEP_UP';
      else if (this.recent.length < 3) state = 'INSUFFICIENT_EVIDENCE';
      else if (A < P.stepup_level) state = 'STEP_UP';
      else if (highRisk && A < P.high_risk_level) state = 'RESTRICTED';
      else if (A >= P.trust_level && this.recent.length >= Math.min(P.K, 3)) state = 'TRUSTED';
      else state = this.recent.length < 3 ? 'INSUFFICIENT_EVIDENCE' : (A >= P.trust_level ? 'TRUSTED' : 'STEP_UP');
      this.state = state; let upd = 'not admitted';
      if (state === 'TRUSTED' && s <= t.tau_g) { const [ok, why] = sabaUpdate(t, z, day); upd = (ok ? 'silent, ' : 'rejected: ') + why; }
      else if (state === 'STEP_UP' || state === 'RESTRICTED') { this.pending.push([modality, z]); upd = 'held pending verified label'; }
      const risk = sessionRisk(A, this.cusum, bound);
      Object.assign(out, { score: +s.toFixed(3), confidence: +conf.toFixed(3), assurance: +A.toFixed(3), cusum: +this.cusum.toFixed(3),
        risk: +risk.toFixed(3), takeover: this.cusum >= bound,
        cusum_bound: +bound.toFixed(3), decision: state, update: upd,
        latency_ms: +(((typeof performance !== 'undefined' ? performance.now() : Date.now()) - t0)).toFixed(3) });
      this.log.push(out); return out;
    }
    stepUp(success, day = 0) {
      let res;
      if (success) { let n = 0; for (const [m, z] of this.pending) { const [ok] = sabaUpdate(this.templates[m], z, day); n += ok ? 1 : 0; }
        this.pending = []; this.cusum = 0; this.recent = []; this.stepupFailures = 0; this.state = 'TRUSTED';
        this.snapshot(`verified-label update (${n} windows)`); res = { decision: 'TRUSTED', verified_updates: n };
      } else { this.stepupFailures++; this.pending = [];
        const ver = this.versions.filter((v) => v.reason.startsWith('enrolment') || v.reason.startsWith('verified'));
        const back = ver[ver.length - 1].version; this.restore(back);
        this.state = this.stepupFailures >= 2 ? 'DENIED' : 'STEP_UP'; res = { decision: this.state, rolled_back_to: back }; }
      this.log.push({ event: 'step_up', ...res }); return res;
    }
  }

  const api = { EVENT_FEATURES, WINDOW_EVENTS, MIN_EVENTS, P, windowVector, enrol, enrolDeep, sessionRisk, eerThreshold, quantile, median, score, confidence, sabaUpdate, Session, trainLogreg };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.BehCore = api;
})(typeof window !== 'undefined' ? window : globalThis);
