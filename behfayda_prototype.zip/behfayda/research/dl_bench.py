"""Deep-learning benchmark on BahriApp under the reconciled leakage-safe protocol.

Protocol (identical evaluation rules to reconcile.py, plus user-disjoint representation learning):
  * users are assigned to 3 folds by a hash of the user id (same assignment for every modality);
    the encoder for fold f is trained ONLY on users outside fold f (development users);
  * for every target user u in fold f: enrolment = earliest 60% of u's sittings (30-min gap rule),
    genuine test = later sittings; impostor test = later-sitting windows of the OTHER fold-f users,
    who were never seen by the encoder nor by u's template (unseen impostors);
  * features: behaviour-only event columns that pass the P3-style scope audit (no ids, timestamps,
    screen positions, session aggregates, device constants);
  * evidence unit: non-overlapping windows of W consecutive events inside one session; K-window
    decisions average K consecutive window scores of one identity (no overlap).
Scorers on top of the frozen encoder:
  cos : cosine similarity to the mean enrolment embedding (enrolment uses genuine data only)
  lr  : logistic head on embeddings, negatives drawn from development users only.
Outputs: per-user EER summary CSV and a pickle of score streams for fusion.
"""
import sys, os, json, time, pickle, zlib
import numpy as np, pandas as pd
import jax, jax.numpy as jnp, optax
from flax import linen as nn
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_curve

D = os.environ.get('BAHRIAPP_DATA', 'BahriApp-Dataset')
GAP = 30 * 60
NFOLD = 3

# ----------------------------------------------------------------------------- data
def to_sec(s):
    t = pd.to_datetime(s, errors='coerce')
    return (t - pd.Timestamp('1970-01-01')).dt.total_seconds()

KS_FILES = {'ks_en': 'Keystroke_Data_English.csv', 'ks_am': 'Keystroke_Data_Amharic.csv',
            'ks_pw': 'Keystroke_PasswordText_Data.csv', 'ks_fe': 'Keystroke_FreeText_Data_English.csv',
            'ks_fa': 'Keystroke_FreeText_Data_Amharic.csv'}

def load(mod):
    if mod == 'tap':
        df = pd.read_csv(f'{D}/Tap_Data.csv')
        df['sess'] = df['id'].astype(str) + '|' + df['startTime'].astype(str)
        df['t'] = to_sec(df['startTime'])
        df['offX'] = df['TapInitialLocalLocationX'] / np.sqrt(df['_targetSizeAre'])
        df['offY'] = df['TapInitialLocalLocationY'] / np.sqrt(df['_targetSizeAre'])
        cols = ['TapDuration', 'TapLocalMovementX', 'TapLocalMovementY', 'offX', 'offY']
    elif mod == 'swipe':
        df = pd.read_csv(f'{D}/Swipe_Data.csv')
        df['sess'] = df['id'].astype(str) + '|' + df['sessionId'].astype(str)
        df['t'] = df['startTime'].astype(float)
        cols = ['duration', 'speed', 'acceleration', 'jerk', 'distance', 'movementVariability',
                'straightness', 'angle', 'areaCoverage']
    elif mod in KS_FILES:
        df = pd.read_csv(f'{D}/{KS_FILES[mod]}')
        df['sess'] = df['id'].astype(str) + '|' + df['sessionId'].astype(str)
        df['t'] = to_sec(df['TimeStamp'])
        df = df[(df['holdTime'] > 0) & (df['holdTime'] < 2000)].copy()
        for c in ('flightTime', 'interKeyTime'):
            df.loc[(df[c] < 0) | (df[c] > 5000), c] = np.nan
        cols = ['holdTime', 'flightTime', 'interKeyTime']
    elif mod == 'gyro':
        df = pd.read_csv(f'{D}/Gyroscope_Data.csv')
        df['sess'] = df['id'].astype(str) + '|' + df['sessionId'].astype(str)
        df['t'] = to_sec(df['timestamp'])
        cols = ['gyroX', 'gyroY', 'gyroZ', 'jerk', 'tiltAcceleration', 'tiltSpeed',
                'rotationDuration', 'rotationDirectionConsistency']
    else:
        raise ValueError(mod)
    df['user'] = df['id'].astype(str)
    return df, cols

def scope_audit(df, cols, tau=0.95):
    kept = []
    for c in cols:
        s_const = (df.groupby('sess')[c].nunique(dropna=True) <= 1).mean()
        u_const = (df.groupby('user')[c].nunique(dropna=True) <= 1).mean()
        if s_const < tau and u_const < tau and not any(df[c].equals(df[o]) for o in kept):
            kept.append(c)
    return kept

def fold_of(u):
    return zlib.crc32(u.encode()) % NFOLD

def sessions(mod):
    df, cols = load(mod)
    cols = scope_audit(df, cols)
    X = df[cols].to_numpy(float)
    # unsupervised monotone transform (no labels): signed log for heavy-tailed columns
    for j in range(X.shape[1]):
        v = X[:, j]; v = v[np.isfinite(v)]
        if len(v) and abs(pd.Series(v).skew()) > 2:
            X[:, j] = np.sign(X[:, j]) * np.log1p(np.abs(X[:, j]))
    df = df.assign(**{f'_f{j}': X[:, j] for j in range(X.shape[1])})
    fc = [f'_f{j}' for j in range(X.shape[1])]
    out = []
    for (u, s), g in df.sort_values('t').groupby(['user', 'sess'], sort=False):
        out.append(dict(user=u, sess=s, t0=float(g['t'].iloc[0]), E=g[fc].to_numpy(np.float32),
                        T=g['t'].to_numpy(float)))
    # sittings
    by_u = {}
    for i, o in enumerate(out):
        by_u.setdefault(o['user'], []).append(i)
    for u, idx in by_u.items():
        idx.sort(key=lambda i: (np.nan_to_num(out[i]['t0'], nan=0.0)))
        k, prev = 0, None
        for i in idx:
            t = out[i]['t0']
            if prev is not None and (np.isnan(t) or np.isnan(prev) or t - prev > GAP):
                k += 1
            out[i]['sit'] = k; prev = t
    return out, cols

def make_windows(sess, W):
    rows = []
    for si, o in enumerate(sess):
        n = len(o['E']) // W
        for k in range(n):
            rows.append((o['user'], o['sit'], o['T'][k * W] if np.isfinite(o['T'][k * W]) else o['t0'],
                         o['E'][k * W:(k + 1) * W], si))
    U = np.array([r[0] for r in rows]); S = np.array([r[1] for r in rows])
    T = np.array([r[2] for r in rows], float); X = np.stack([r[3] for r in rows]); SI = np.array([r[4] for r in rows])
    return U, S, T, X, SI

def stats(X):
    """X: (N,W,F) normalised -> (N,5F) window statistics."""
    return np.concatenate([np.nanmean(X, 1), np.nanstd(X, 1), np.nanpercentile(X, 25, 1),
                           np.nanmedian(X, 1), np.nanpercentile(X, 75, 1)], 1).astype(np.float32)

# ----------------------------------------------------------------------------- models
class StatsMLP(nn.Module):
    emb: int = 128
    @nn.compact
    def __call__(self, x, st, train):
        h = st
        for w in (256, 256):
            h = nn.Dense(w)(h); h = nn.LayerNorm()(h); h = nn.gelu(h)
            h = nn.Dropout(0.2, deterministic=not train)(h)
        return nn.Dense(self.emb)(h)

class CNN1D(nn.Module):
    emb: int = 128
    @nn.compact
    def __call__(self, x, st, train):
        h = nn.Dense(64)(x)
        for _ in range(3):
            r = h
            h = nn.Conv(64, (3,), padding='SAME')(h); h = nn.LayerNorm()(h); h = nn.gelu(h)
            h = nn.Dropout(0.1, deterministic=not train)(h); h = h + r
        p = jnp.concatenate([h.mean(1), h.max(1)], -1)
        return nn.Dense(self.emb)(nn.gelu(nn.Dense(128)(p)))

class BiGRU(nn.Module):
    emb: int = 128
    @nn.compact
    def __call__(self, x, st, train):
        h = nn.Dense(64)(x)
        f = nn.RNN(nn.GRUCell(64))(h)
        b = nn.RNN(nn.GRUCell(64), reverse=True, keep_order=True)(h)
        h = jnp.concatenate([f, b], -1)
        p = jnp.concatenate([h.mean(1), f[:, -1], b[:, 0]], -1)
        p = nn.Dropout(0.1, deterministic=not train)(p)
        return nn.Dense(self.emb)(nn.gelu(nn.Dense(128)(p)))

class TfBlock(nn.Module):
    d: int
    @nn.compact
    def __call__(self, h, train):
        a = nn.MultiHeadDotProductAttention(num_heads=4, qkv_features=self.d,
                                            deterministic=not train, dropout_rate=0.1)(nn.LayerNorm()(h))
        h = h + a
        m = nn.Dense(self.d)(nn.gelu(nn.Dense(2 * self.d)(nn.LayerNorm()(h))))
        return h + nn.Dropout(0.1, deterministic=not train)(m)

class Transformer(nn.Module):
    emb: int = 128
    d: int = 64
    @nn.compact
    def __call__(self, x, st, train):
        W = x.shape[1]
        h = nn.Dense(self.d)(x) + self.param('pos', nn.initializers.normal(0.02), (1, W, self.d))
        for _ in range(2):
            h = TfBlock(self.d)(h, train)
        h = nn.LayerNorm()(h)
        return nn.Dense(self.emb)(nn.gelu(nn.Dense(128)(h.mean(1))))

class Hybrid(nn.Module):
    """CNN + Transformer sequence branches fused with a window-statistics branch."""
    emb: int = 128
    @nn.compact
    def __call__(self, x, st, train):
        a = CNN1D(64)(x, st, train)
        b = Transformer(64)(x, st, train)
        c = StatsMLP(64)(x, st, train)
        h = jnp.concatenate([a, b, c], -1)
        h = nn.Dropout(0.1, deterministic=not train)(nn.gelu(nn.Dense(192)(h)))
        return nn.Dense(self.emb)(h)

MODELS = dict(mlp=StatsMLP, cnn=CNN1D, gru=BiGRU, tf=Transformer, hybrid=Hybrid)

class Net(nn.Module):
    enc: str
    n_cls: int
    @nn.compact
    def __call__(self, x, st, train):
        e = MODELS[self.enc]()(x, st, train)
        e = e / (jnp.linalg.norm(e, axis=-1, keepdims=True) + 1e-6)
        Wc = self.param('cls', nn.initializers.normal(0.1), (self.n_cls, e.shape[-1]))
        Wc = Wc / (jnp.linalg.norm(Wc, axis=-1, keepdims=True) + 1e-6)
        return e, e @ Wc.T

def cosface_loss(logits, y, s=16.0, m=0.25):
    oh = jax.nn.one_hot(y, logits.shape[-1])
    z = s * (logits - m * oh)
    return optax.softmax_cross_entropy(z, oh).mean()

# ----------------------------------------------------------------------------- training
def train_encoder(enc, dev_sess, W, mu, sd, steps, seed, crop_aug=True, batch=256):
    users = sorted({o['user'] for o in dev_sess})
    uid = {u: i for i, u in enumerate(users)}
    elig = [o for o in dev_sess if len(o['E']) >= W]
    lens = np.array([len(o['E']) - W + 1 for o in elig], float)
    # balance users: sample a user uniformly, then a session by length within that user
    per_u = {}
    for i, o in enumerate(elig):
        per_u.setdefault(uid[o['user']], []).append(i)
    keys = np.array(sorted(per_u))
    rng = np.random.default_rng(seed)
    net = Net(enc, len(users))
    x0 = jnp.zeros((2, W, len(mu))); s0 = jnp.zeros((2, 5 * len(mu)))
    params = net.init({'params': jax.random.PRNGKey(seed), 'dropout': jax.random.PRNGKey(seed + 1)},
                      x0, s0, False)['params']
    sched = optax.warmup_cosine_decay_schedule(0, 2e-3, 150, steps, 1e-5)
    opt = optax.chain(optax.clip_by_global_norm(1.0), optax.adamw(sched, weight_decay=1e-4))
    state = opt.init(params)

    @jax.jit
    def step(params, state, x, st, y, key):
        def lf(p):
            _, lg = net.apply({'params': p}, x, st, True, rngs={'dropout': key})
            return cosface_loss(lg, y)
        l, g = jax.value_and_grad(lf)(params)
        up, state = opt.update(g, state, params)
        return optax.apply_updates(params, up), state, l

    key = jax.random.PRNGKey(seed + 7)
    for it in range(steps):
        us = rng.choice(keys, batch)
        xb = np.empty((batch, W, len(mu)), np.float32); yb = us.astype(np.int32)
        for b, u in enumerate(us):
            cand = per_u[u]; i = cand[rng.integers(len(cand))] if len(cand) == 1 else \
                rng.choice(cand, p=lens[cand] / lens[cand].sum())
            E = elig[i]['E']
            st0 = rng.integers(len(E) - W + 1) if crop_aug else (rng.integers(len(E) // W) * W)
            xb[b] = E[st0:st0 + W]
        xb = np.clip(np.nan_to_num((xb - mu) / sd), -5, 5)
        if crop_aug:  # light jitter augmentation in normalised space
            xb = xb + rng.normal(0, 0.05, xb.shape).astype(np.float32)
        key, k2 = jax.random.split(key)
        params, state, l = step(params, state, jnp.asarray(xb), jnp.asarray(stats(xb)), jnp.asarray(yb), k2)
    apply = jax.jit(lambda p, x, st: net.apply({'params': p}, x, st, False)[0])
    def embed(X):
        out = []
        for i in range(0, len(X), 2048):
            xb = X[i:i + 2048]
            out.append(np.asarray(apply(params, jnp.asarray(xb), jnp.asarray(stats(xb)))))
        return np.concatenate(out)
    return embed, float(l)

# ----------------------------------------------------------------------------- evaluation
def eer(y, s):
    fpr, tpr, thr = roc_curve(y, s)
    fnr = 1 - tpr
    i = np.nanargmin(np.abs(fnr - fpr))
    return float((fpr[i] + fnr[i]) / 2)

def kagg(scores, T, K):
    o = np.argsort(T); v = scores[o]
    return np.array([v[j:j + K].mean() for j in range(0, len(v) - K + 1, K)]) if K > 1 else v

def run(mod, W, encs, steps, K_list=(1, 5, 10), seed=0, tag='', on_encoder=None):
    sess, cols = sessions(mod)
    U, S, T, X, SI = make_windows(sess, W)
    users = np.unique(U)
    nsit = {u: S[U == u].max() + 1 for u in users}
    cut = {u: max(1, int(round(0.6 * nsit[u]))) for u in users}
    elig = [u for u in users if nsit[u] >= 3 and (U == u).sum() >= 15]
    later = np.array([S[i] >= cut[U[i]] for i in range(len(U))])
    fold = np.array([fold_of(u) for u in U])
    results, streams, log = [], {}, []
    for enc in encs:
        per = {('cos', K): {} for K in K_list}; per.update({('lr', K): {} for K in K_list})
        t0 = time.time()
        for f in range(NFOLD):
            dev_mask = fold != f
            dev_sess = [o for o in sess if fold_of(o['user']) != f]
            allE = np.concatenate([o['E'] for o in dev_sess])
            mu = np.nanmean(allE, 0).astype(np.float32); sd = (np.nanstd(allE, 0) + 1e-6).astype(np.float32)
            embed, lfin = train_encoder(enc, dev_sess, W, mu, sd, steps, seed + 101 * f)
            Xn = np.clip(np.nan_to_num((X - mu) / sd), -5, 5).astype(np.float32)
            Z = embed(Xn)
            rng = np.random.default_rng(seed + f)
            dev_idx = np.where(dev_mask)[0]
            neg = rng.choice(dev_idx, min(3000, len(dev_idx)), replace=False)
            tgt = [u for u in elig if fold_of(u) == f]
            for u in tgt:
                gi = np.where(U == u)[0]
                g_tr = gi[S[gi] < cut[u]]; g_te = gi[S[gi] >= cut[u]]
                if len(g_tr) < 10 or len(g_te) < 5:
                    continue
                imp = np.where((fold == f) & (U != u) & later)[0]
                if len(imp) < 10:
                    continue
                c = Z[g_tr].mean(0); c /= np.linalg.norm(c) + 1e-9
                sc_cos = Z @ c
                clf = LogisticRegression(C=1.0, class_weight='balanced', max_iter=2000).fit(
                    np.vstack([Z[g_tr], Z[neg]]), np.r_[np.ones(len(g_tr)), np.zeros(len(neg))])
                sc_lr = clf.decision_function(Z)
                for name, sc in (('cos', sc_cos), ('lr', sc_lr)):
                    streams.setdefault((mod, enc, name), {})[u] = dict(
                        gen=(sc[g_te], T[g_te], S[g_te]),
                        imp={o: (sc[imp][U[imp] == o], T[imp][U[imp] == o]) for o in np.unique(U[imp])})
                    for K in K_list:
                        a = kagg(sc[g_te], T[g_te], K)
                        b = np.concatenate([kagg(sc[imp][U[imp] == o], T[imp][U[imp] == o], K)
                                            for o in np.unique(U[imp])])
                        if len(a) < 2 or len(b) < 2:
                            continue
                        per[(name, K)][u] = eer(np.r_[np.ones(len(a)), np.zeros(len(b))], np.r_[a, b])
            log.append(dict(mod=mod, enc=enc, fold=f, final_loss=round(lfin, 3)))
        brng = np.random.default_rng(0)
        for (name, K), d in per.items():
            if not d:
                continue
            v = np.array(list(d.values()))
            boots = [np.median(brng.choice(v, len(v))) for _ in range(2000)]
            results.append(dict(modality=mod, W=W, encoder=enc, scorer=name, K=K, n_users=len(v),
                                median_eer=round(float(np.median(v)), 4),
                                ci_low=round(float(np.percentile(boots, 2.5)), 4),
                                ci_high=round(float(np.percentile(boots, 97.5)), 4),
                                mean_eer=round(float(v.mean()), 4),
                                acc_at_eer=round(1 - float(np.median(v)), 4),
                                frac_users_acc90=round(float((v <= 0.10).mean()), 3),
                                features='|'.join(cols), steps=steps, secs=round(time.time() - t0)))
        print(pd.DataFrame([r for r in results if r['encoder'] == enc])[
            ['modality', 'encoder', 'scorer', 'K', 'n_users', 'median_eer', 'ci_low', 'ci_high', 'acc_at_eer',
             'frac_users_acc90', 'secs']].to_string(), flush=True)
        if on_encoder: on_encoder(results, streams, log)
    return results, streams, log

if __name__ == '__main__':
    mods = sys.argv[1].split(','); encs = sys.argv[2].split(','); steps = int(sys.argv[3])
    out = sys.argv[4]; Wover = json.loads(sys.argv[5]) if len(sys.argv) > 5 else {}
    os.makedirs(out, exist_ok=True)
    Ws = dict(tap=12, swipe=5, ks_en=9, ks_am=7, ks_pw=5, gyro=3, ks_fe=9, ks_fa=7)
    Ws.update(Wover)
    allr, alls, alll = [], {}, []
    name = f"{'_'.join(mods)}__{'_'.join(encs)}__{steps}" + ('__W' + '_'.join(f'{k}{v}' for k, v in Wover.items()) if Wover else '')
    def save(r, s, l):   # checkpoint after every encoder so an interrupted run keeps its results
        pd.DataFrame(allr + r).to_csv(f'{out}/dl_{name}.csv', index=False)
        pickle.dump({**alls, **s}, open(f'{out}/streams_{name}.pkl', 'wb'))
        json.dump(alll + l, open(f'{out}/log_{name}.json', 'w'), indent=1)
    for m in mods:
        r, s, l = run(m, Ws[m], encs, steps, on_encoder=save)
        allr += r; alls.update(s); alll += l
        save([], {}, [])
