"""Score-level ensemble (deep encoder + random forest) and session-level multimodal fusion on BahriApp.

Leakage-safe rules (same as dl_bench.py, plus a CROSS-MODAL sitting split):
  * a user's sessions of ALL modalities are merged on one clock and cut into sittings (30-min gap);
    enrolment = earliest 60% of the user's sittings, test = the later sittings (one split for every modality);
  * encoders, random forests and logistic heads see development users only (other folds) plus the
    target's own enrolment windows; test impostors are other users of the same fold (never seen);
  * scores are Z-normalised per target model on a held-out development cohort (not on test data).
Evaluation units:
  (a) per-modality K-window decisions for DL, RF and the DL+RF ensemble;
  (b) session-level fusion: for each test sitting of a claimed identity, average the normalised scores of
      the first M windows of every modality observed in that sitting, then average across modalities.
usage: python fusion_bench.py '{"tap":"mlp",...}' steps outdir
"""
import sys, os, json, pickle, time
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import dl_bench as B
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression

ENC = json.loads(sys.argv[1]); STEPS = int(sys.argv[2]); OUT = sys.argv[3]; os.makedirs(OUT, exist_ok=True)
MODS = list(ENC)
W = dict(tap=12, swipe=5, ks_en=9, ks_am=7, ks_pw=5, gyro=3, ks_fe=9, ks_fa=7)
GAP = 30 * 60

# ------------------------------------------------------------------ data + cross-modal sittings
data = {}
starts = {}
for m in MODS:
    sess, cols = B.sessions(m)
    U, S, T, X, SI = B.make_windows(sess, W[m])
    t0 = np.array([sess[i]['t0'] for i in SI])
    data[m] = dict(sess=sess, cols=cols, U=U, T=T, X=X, t0=t0)
    for o in sess:
        if np.isfinite(o['t0']):
            starts.setdefault(o['user'], set()).add(o['t0'])
sitting_of = {}
for u, ts in starts.items():
    ts = sorted(ts); k = 0; prev = None; lab = {}
    for t in ts:
        if prev is not None and t - prev > GAP: k += 1
        lab[t] = k; prev = t
    sitting_of[u] = lab
nsit = {u: max(v.values()) + 1 for u, v in sitting_of.items()}
cut = {u: max(1, int(round(0.6 * nsit[u]))) for u in nsit}
for m in MODS:
    d = data[m]
    d['G'] = np.array([sitting_of.get(u, {}).get(t, -1) for u, t in zip(d['U'], d['t0'])])
    d['later'] = np.array([g >= cut.get(u, 1) for u, g in zip(d['U'], d['G'])])
    d['fold'] = np.array([B.fold_of(u) for u in d['U']])
users = sorted(nsit)
print('users', len(users), 'with >=3 sittings', sum(nsit[u] >= 3 for u in users), flush=True)

# ------------------------------------------------------------------ scoring
def znorm(sc_all, coh_idx):
    c = sc_all[coh_idx]; return (sc_all - c.mean()) / (c.std() + 1e-9)

scores = {}   # (m, scorer) -> {u: array of per-window normalised scores for ALL windows of modality m}
for m in MODS:
    d = data[m]; t0 = time.time()
    for f in range(B.NFOLD):
        dev_sess = [o for o in d['sess'] if B.fold_of(o['user']) != f]
        allE = np.concatenate([o['E'] for o in dev_sess])
        mu = np.nanmean(allE, 0).astype(np.float32); sd = (np.nanstd(allE, 0) + 1e-6).astype(np.float32)
        embed, _ = B.train_encoder(ENC[m], dev_sess, W[m], mu, sd, STEPS, 0 + 101 * f)
        Xn = np.clip(np.nan_to_num((d['X'] - mu) / sd), -5, 5).astype(np.float32)
        Z = embed(Xn); ST = np.nan_to_num(B.stats(Xn))
        rng = np.random.default_rng(f)
        dev_idx = np.where(d['fold'] != f)[0]; rng.shuffle(dev_idx)
        neg = dev_idx[:min(3000, len(dev_idx) // 2)]; coh = dev_idx[len(neg):len(neg) + 2000]
        for u in [u for u in users if B.fold_of(u) == f and nsit[u] >= 3]:
            gi = np.where(d['U'] == u)[0]; g_tr = gi[(d['G'][gi] >= 0) & (d['G'][gi] < cut[u])]
            if len(g_tr) < 8:
                continue
            ytr = np.r_[np.ones(len(g_tr)), np.zeros(len(neg))]
            lr = LogisticRegression(C=1.0, class_weight='balanced', max_iter=2000).fit(np.vstack([Z[g_tr], Z[neg]]), ytr)
            rf = RandomForestClassifier(150, min_samples_leaf=2, class_weight='balanced', n_jobs=1, random_state=f).fit(
                np.vstack([ST[g_tr], ST[neg]]), ytr)
            s_dl = znorm(lr.decision_function(Z), coh)
            p = np.clip(rf.predict_proba(ST)[:, 1], 1e-3, 1 - 1e-3); s_rf = znorm(np.log(p / (1 - p)), coh)
            scores.setdefault((m, 'dl'), {})[u] = s_dl
            scores.setdefault((m, 'rf'), {})[u] = s_rf
            scores.setdefault((m, 'ens'), {})[u] = (s_dl + s_rf) / 2
    print(m, 'scored', round(time.time() - t0), 's', flush=True)
pickle.dump(dict(scores=scores, cut=cut, nsit=nsit), open(f'{OUT}/fusion_scores.pkl', 'wb'))

# ------------------------------------------------------------------ evaluation helpers
brng = np.random.default_rng(0)
def summarise(per_user, pooled=None, **kw):
    v = np.array(list(per_user.values()))
    pe = None
    if pooled is not None and len(pooled[0]) > 1 and len(pooled[1]) > 1:
        pe = round(B.eer(np.r_[np.ones(len(pooled[0])), np.zeros(len(pooled[1]))], np.r_[pooled[0], pooled[1]]), 4)
    boots = [np.median(brng.choice(v, len(v))) for _ in range(2000)]
    return dict(**kw, n_users=len(v), median_eer=round(float(np.median(v)), 4),
                ci_low=round(float(np.percentile(boots, 2.5)), 4), ci_high=round(float(np.percentile(boots, 97.5)), 4),
                mean_eer=round(float(v.mean()), 4), acc_at_eer=round(1 - float(np.median(v)), 4),
                frac_users_acc90=round(float((v <= 0.10).mean()), 3), pooled_eer=pe)

rows = []
# (a) per-modality K-window decisions
for m in MODS:
    d = data[m]
    for sc in ('dl', 'rf', 'ens'):
        for K in (1, 3, 5, 10):
            per = {}; PA, PB = [], []
            for u, s in scores.get((m, sc), {}).items():
                f = B.fold_of(u)
                gte = np.where((d['U'] == u) & d['later'])[0]
                imp = np.where((d['fold'] == f) & (d['U'] != u) & d['later'])[0]
                if len(gte) < 2 or len(imp) < 10:
                    continue
                a = B.kagg(s[gte], d['T'][gte], K)
                b = np.concatenate([B.kagg(s[imp][d['U'][imp] == o], d['T'][imp][d['U'][imp] == o], K) for o in np.unique(d['U'][imp])])
                if len(a) >= 2 and len(b) >= 2:
                    PA.append(a); PB.append(b)
                    per[u] = B.eer(np.r_[np.ones(len(a)), np.zeros(len(b))], np.r_[a, b])
            if per:
                rows.append(summarise(per, (np.concatenate(PA), np.concatenate(PB)), unit='window', modality=m, scorer=sc, K=K, M=None, n_mod=1))
        print(pd.DataFrame([r for r in rows if r['modality'] == m])[['modality', 'scorer', 'K', 'n_users', 'median_eer', 'pooled_eer', 'acc_at_eer']].to_string(), flush=True)

# (b) session-level multimodal fusion
def session_scores(u_model, sc, mods, M):
    """returns list of (claimant, sitting, fused score, n_modalities) for all later sittings of fold users."""
    f = B.fold_of(u_model); out = {}
    for m in mods:
        if (m, sc) not in scores or u_model not in scores[(m, sc)]:
            continue
        d = data[m]; s = scores[(m, sc)][u_model]
        idx = np.where((d['fold'] == f) & d['later'] & (d['G'] >= 0))[0]
        df = pd.DataFrame({'c': d['U'][idx], 'g': d['G'][idx], 't': d['T'][idx], 's': s[idx]}).sort_values('t')
        agg = df.groupby(['c', 'g'])['s'].apply(lambda v: v.iloc[:M].mean() if M else v.mean())
        for (c, g), v in agg.items():
            out.setdefault((c, g), []).append(v)
    return [(c, g, float(np.mean(v)), len(v)) for (c, g), v in out.items()]

COMBOS = {'all': MODS, 'touch+typing': [m for m in MODS if m in ('tap', 'swipe', 'ks_en', 'ks_am', 'ks_pw')],
          'tap+ks_en+swipe': [m for m in MODS if m in ('tap', 'ks_en', 'swipe')]}
for cname, mods in COMBOS.items():
    for sc in ('dl', 'rf', 'ens'):
        for M in (1, 2, 3, 5, None):
            for min_mod in (1, 2):
                per = {}; nm = []; PA, PB = [], []
                for u in {u for m in mods for u in scores.get((m, sc), {})}:
                    ss = [x for x in session_scores(u, sc, mods, M) if x[3] >= min_mod]
                    a = np.array([x[2] for x in ss if x[0] == u]); b = np.array([x[2] for x in ss if x[0] != u])
                    if len(a) >= 1 and len(b) >= 5 and len(a) + len(b) >= 8:
                        per[u] = B.eer(np.r_[np.ones(len(a)), np.zeros(len(b))], np.r_[a, b]); nm += [x[3] for x in ss]
                        PA.append(a); PB.append(b)
                if per:
                    r = summarise(per, (np.concatenate(PA), np.concatenate(PB)), unit='sitting', modality=cname, scorer=sc, K=None, M=M if M else 'all', n_mod=round(float(np.mean(nm)), 2))
                    r['min_modalities'] = min_mod; rows.append(r)
    print(pd.DataFrame([r for r in rows if r['modality'] == cname])[['modality', 'scorer', 'M', 'min_modalities', 'n_users', 'n_mod', 'median_eer', 'pooled_eer', 'acc_at_eer']].to_string(), flush=True)
pd.DataFrame(rows).to_csv(f'{OUT}/fusion_summary.csv', index=False)
print('done')
